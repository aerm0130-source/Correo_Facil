package com.correoclaro.app.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Ui {
    public static final int BG = Color.rgb(6, 14, 24);
    public static final int PANEL = Color.rgb(12, 25, 39);
    public static final int PANEL2 = Color.rgb(17, 34, 52);
    public static final int PANEL3 = Color.rgb(21, 42, 62);
    public static final int CYAN = Color.rgb(34, 211, 238);
    public static final int BLUE = Color.rgb(96, 165, 250);
    public static final int TEXT = Color.rgb(248, 250, 252);
    public static final int MUTED = Color.rgb(148, 163, 184);
    public static final int GREEN = Color.rgb(74, 222, 128);
    public static final int YELLOW = Color.rgb(250, 204, 21);
    public static final int RED = Color.rgb(248, 113, 113);
    public static final int LINE = Color.rgb(30, 52, 73);

    public static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable box(int color, int stroke, float radius, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, (int) radius));
        if (stroke != Color.TRANSPARENT) g.setStroke(dp(c, 1), stroke);
        return g;
    }

    public static TextView text(Context c, String value, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }

    public static Button button(Context c, String value, boolean primary) {
        Button b = new Button(c);
        b.setText(value);
        b.setTextColor(primary ? Color.rgb(4, 17, 29) : TEXT);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackground(box(primary ? CYAN : PANEL2, primary ? Color.TRANSPARENT : LINE, 12, c));
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        b.setMinHeight(dp(c, 44));
        b.setMinimumHeight(0);
        b.setMinimumWidth(0);
        return b;
    }

    public static Button compactButton(Context c, String value, boolean primary) {
        Button b = button(c, value, primary);
        b.setTextSize(12);
        b.setPadding(dp(c, 10), 0, dp(c, 10), 0);
        b.setMinHeight(dp(c, 38));
        return b;
    }

    public static Button navButton(Context c, String value) {
        Button b = button(c, value, false);
        b.setBackground(box(PANEL, Color.TRANSPARENT, 10, c));
        b.setTextSize(12);
        b.setPadding(dp(c, 6), 0, dp(c, 6), 0);
        b.setMinHeight(dp(c, 46));
        return b;
    }

    public static EditText input(Context c, String hint) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setPadding(dp(c, 12), 0, dp(c, 12), 0);
        e.setBackground(box(PANEL2, LINE, 10, c));
        e.setMinHeight(dp(c, 46));
        return e;
    }

    public static EditText multiline(Context c, String hint, int minLines) {
        EditText e = input(c, hint);
        e.setSingleLine(false);
        e.setMinLines(minLines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
        return e;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c, 14), dp(c, 14), dp(c, 14), dp(c, 14));
        l.setBackground(box(PANEL, LINE, 14, c));
        return l;
    }

    public static LinearLayout selectedCard(Context c) {
        LinearLayout l = card(c);
        l.setBackground(box(PANEL2, CYAN, 14, c));
        return l;
    }

    public static TextView badge(Context c, String value, int color) {
        TextView t = text(c, value, 11, color, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 9), dp(c, 4), dp(c, 9), dp(c, 4));
        t.setBackground(box(PANEL2, LINE, 20, c));
        return t;
    }

    public static LinearLayout.LayoutParams mp(int h) {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h);
    }
}
