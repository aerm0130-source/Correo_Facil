package com.correoclaro.app.data;

import android.content.Context;

import com.correoclaro.app.model.MailAccount;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AccountStore {
    private static final String ACCOUNTS = "accounts";
    private final SecurePrefs secure;

    public AccountStore(Context context) {
        secure = new SecurePrefs(context);
    }

    public List<MailAccount> all() {
        List<MailAccount> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(secure.get(ACCOUNTS, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                out.add(MailAccount.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public MailAccount save(MailAccount account) {
        if (account.id == null || account.id.isEmpty()) account.id = UUID.randomUUID().toString();
        List<MailAccount> list = all();
        boolean replaced = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(account.id)) {
                list.set(i, account);
                replaced = true;
                break;
            }
        }
        if (!replaced) list.add(account);
        persist(list);
        return account;
    }

    public void delete(String id) {
        List<MailAccount> list = all();
        list.removeIf(a -> a.id.equals(id));
        persist(list);
        secure.remove("ms_auth_" + id);
        secure.remove("imap_pass_" + id);
    }

    public MailAccount byId(String id) {
        for (MailAccount a : all()) if (a.id.equals(id)) return a;
        return null;
    }

    private void persist(List<MailAccount> list) {
        JSONArray arr = new JSONArray();
        try {
            for (MailAccount a : list) arr.put(a.toJson());
            secure.put(ACCOUNTS, arr.toString());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public SecurePrefs secure() { return secure; }
}
