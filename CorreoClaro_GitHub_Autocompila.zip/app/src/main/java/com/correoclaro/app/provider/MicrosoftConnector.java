package com.correoclaro.app.provider;

import com.correoclaro.app.core.MailClassifier;
import com.correoclaro.app.model.MailItem;
import com.correoclaro.app.net.HttpJson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class MicrosoftConnector {

    public static JSONObject profile(String accessToken) throws Exception {
        return HttpJson.get(
                "https://graph.microsoft.com/v1.0/me?$select=displayName,mail,userPrincipalName",
                accessToken);
    }

    public static List<MailItem> sync(String accountId, String accessToken) throws Exception {
        String url = "https://graph.microsoft.com/v1.0/me/messages" +
                "?$top=50&$orderby=receivedDateTime%20desc" +
                "&$select=id,subject,bodyPreview,receivedDateTime,isRead,from";
        JSONObject data = HttpJson.get(url, accessToken);
        JSONArray arr = data.optJSONArray("value");
        List<MailItem> out = new ArrayList<>();
        if (arr == null) return out;

        for (int i = 0; i < arr.length(); i++) {
            JSONObject j = arr.getJSONObject(i);
            MailItem m = new MailItem();
            m.remoteId = j.optString("id");
            m.accountId = accountId;
            m.subject = j.optString("subject");
            m.snippet = j.optString("bodyPreview");
            m.unread = !j.optBoolean("isRead", true);
            m.receivedAt = parseDate(j.optString("receivedDateTime"));

            JSONObject from = j.optJSONObject("from");
            JSONObject addr = from == null ? null : from.optJSONObject("emailAddress");
            if (addr != null) {
                String name = addr.optString("name");
                String email = addr.optString("address");
                m.from = name.isEmpty() ? email : name + " <" + email + ">";
            } else m.from = "";

            MailClassifier.classify(m);
            out.add(m);
        }
        return out;
    }

    private static long parseDate(String value) {
        try { return Instant.parse(value).toEpochMilli(); }
        catch (Exception e) { return System.currentTimeMillis(); }
    }
}
