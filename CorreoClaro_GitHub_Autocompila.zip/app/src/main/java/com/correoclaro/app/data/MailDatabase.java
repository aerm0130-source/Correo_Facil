package com.correoclaro.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.correoclaro.app.model.MailItem;

import java.util.ArrayList;
import java.util.List;

public class MailDatabase extends SQLiteOpenHelper {
    public MailDatabase(Context context) {
        super(context, "correo_claro.db", null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE mails (" +
                "remote_id TEXT NOT NULL," +
                "account_id TEXT NOT NULL," +
                "sender TEXT," +
                "subject TEXT," +
                "snippet TEXT," +
                "received_at INTEGER," +
                "unread INTEGER," +
                "actionable INTEGER," +
                "category TEXT," +
                "folder TEXT NOT NULL DEFAULT 'INBOX'," +
                "PRIMARY KEY(remote_id, account_id))");
        db.execSQL("CREATE INDEX idx_mails_date ON mails(received_at DESC)");
        db.execSQL("CREATE INDEX idx_mails_folder ON mails(account_id, folder)");
        db.execSQL("CREATE INDEX idx_mails_actionable ON mails(actionable)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            try { db.execSQL("ALTER TABLE mails ADD COLUMN folder TEXT NOT NULL DEFAULT 'INBOX'"); }
            catch (Exception ignored) {}
            db.execSQL("UPDATE mails SET category='', actionable=0, folder='INBOX'");
            try { db.execSQL("CREATE INDEX idx_mails_folder ON mails(account_id, folder)"); }
            catch (Exception ignored) {}
        }
    }

    public void upsert(List<MailItem> items) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (MailItem m : items) {
                ContentValues v = values(m);
                db.insertWithOnConflict("mails", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    private ContentValues values(MailItem m) {
        ContentValues v = new ContentValues();
        v.put("remote_id", m.remoteId);
        v.put("account_id", m.accountId);
        v.put("sender", m.from);
        v.put("subject", m.subject);
        v.put("snippet", m.snippet);
        v.put("received_at", m.receivedAt);
        v.put("unread", m.unread ? 1 : 0);
        v.put("actionable", m.actionable ? 1 : 0);
        v.put("category", m.category == null ? "" : m.category);
        v.put("folder", m.folder == null || m.folder.isEmpty() ? "INBOX" : m.folder);
        return v;
    }

    public List<MailItem> query(String accountId, String folder, boolean pendingOnly, String search, int limit) {
        StringBuilder where = new StringBuilder("1=1");
        List<String> args = new ArrayList<>();

        if (accountId != null && !accountId.isEmpty()) {
            where.append(" AND account_id=?");
            args.add(accountId);
        }
        if (folder != null && !folder.isEmpty()) {
            where.append(" AND folder=?");
            args.add(folder);
        }
        if (pendingOnly) where.append(" AND actionable=1");
        if (search != null && !search.trim().isEmpty()) {
            where.append(" AND (sender LIKE ? OR subject LIKE ? OR snippet LIKE ?)");
            String q = "%" + search.trim() + "%";
            args.add(q); args.add(q); args.add(q);
        }

        List<MailItem> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query(
                "mails", null, where.toString(), args.toArray(new String[0]),
                null, null, "received_at DESC", String.valueOf(limit))) {
            while (c.moveToNext()) out.add(read(c));
        }
        return out;
    }

    private MailItem read(Cursor c) {
        MailItem m = new MailItem();
        m.remoteId = c.getString(c.getColumnIndexOrThrow("remote_id"));
        m.accountId = c.getString(c.getColumnIndexOrThrow("account_id"));
        m.from = c.getString(c.getColumnIndexOrThrow("sender"));
        m.subject = c.getString(c.getColumnIndexOrThrow("subject"));
        m.snippet = c.getString(c.getColumnIndexOrThrow("snippet"));
        m.receivedAt = c.getLong(c.getColumnIndexOrThrow("received_at"));
        m.unread = c.getInt(c.getColumnIndexOrThrow("unread")) == 1;
        m.actionable = c.getInt(c.getColumnIndexOrThrow("actionable")) == 1;
        m.category = c.getString(c.getColumnIndexOrThrow("category"));
        m.folder = c.getString(c.getColumnIndexOrThrow("folder"));
        return m;
    }

    public int countAll() { return scalar("SELECT COUNT(*) FROM mails", null); }
    public int countPending() { return scalar("SELECT COUNT(*) FROM mails WHERE actionable=1", null); }
    public int countUnread() { return scalar("SELECT COUNT(*) FROM mails WHERE unread=1", null); }

    public int countFolder(String accountId, String folder) {
        return scalar("SELECT COUNT(*) FROM mails WHERE account_id=? AND folder=?", new String[]{accountId, folder});
    }

    public int countFolderUnread(String accountId, String folder) {
        return scalar("SELECT COUNT(*) FROM mails WHERE account_id=? AND folder=? AND unread=1", new String[]{accountId, folder});
    }

    private int scalar(String sql, String[] args) {
        try (Cursor c = getReadableDatabase().rawQuery(sql, args)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public void setUnread(String accountId, String remoteId, boolean unread) {
        ContentValues v = new ContentValues();
        v.put("unread", unread ? 1 : 0);
        getWritableDatabase().update("mails", v, "account_id=? AND remote_id=?",
                new String[]{accountId, remoteId});
    }

    public void setPending(String accountId, String remoteId, boolean pending) {
        ContentValues v = new ContentValues();
        v.put("actionable", pending ? 1 : 0);
        getWritableDatabase().update("mails", v, "account_id=? AND remote_id=?",
                new String[]{accountId, remoteId});
    }

    public void setFolder(String accountId, String remoteId, String folder) {
        ContentValues v = new ContentValues();
        v.put("folder", folder);
        getWritableDatabase().update("mails", v, "account_id=? AND remote_id=?",
                new String[]{accountId, remoteId});
    }

    public void deleteMail(String accountId, String remoteId) {
        getWritableDatabase().delete("mails", "account_id=? AND remote_id=?",
                new String[]{accountId, remoteId});
    }

    public void deleteFolderCache(String accountId, String folder) {
        getWritableDatabase().delete("mails", "account_id=? AND folder=?",
                new String[]{accountId, folder});
    }

    public void deleteAccount(String accountId) {
        getWritableDatabase().delete("mails", "account_id=?", new String[]{accountId});
    }
}
