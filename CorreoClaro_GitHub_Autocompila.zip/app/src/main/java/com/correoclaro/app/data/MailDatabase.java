package com.correoclaro.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.correoclaro.app.model.MailItem;

import java.util.ArrayList;
import java.util.List;

public class MailDatabase extends SQLiteOpenHelper {
    public MailDatabase(Context context) {
        super(context, "correo_claro.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE mails (" +
                "remote_id TEXT NOT NULL," +
                "account_id TEXT NOT NULL," +
                "sender TEXT," +
                "subject TEXT," +
                "snippet TEXT," +
                "received_at INTEGER," +
                "unread INTEGER," +
                "actionable INTEGER," +
                "category TEXT," +
                "PRIMARY KEY(remote_id, account_id))");
        db.execSQL("CREATE INDEX idx_mails_date ON mails(received_at DESC)");
        db.execSQL("CREATE INDEX idx_mails_category ON mails(category)");
        db.execSQL("CREATE INDEX idx_mails_actionable ON mails(actionable)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public void upsert(List<MailItem> items) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            for (MailItem m : items) {
                ContentValues v = new ContentValues();
                v.put("remote_id", m.remoteId);
                v.put("account_id", m.accountId);
                v.put("sender", m.from);
                v.put("subject", m.subject);
                v.put("snippet", m.snippet);
                v.put("received_at", m.receivedAt);
                v.put("unread", m.unread ? 1 : 0);
                v.put("actionable", m.actionable ? 1 : 0);
                v.put("category", m.category);
                db.insertWithOnConflict("mails", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public List<MailItem> query(String accountId, String category, boolean actionableOnly, String search, int limit) {
        StringBuilder where = new StringBuilder("1=1");
        List<String> args = new ArrayList<>();

        if (accountId != null && !accountId.isEmpty()) {
            where.append(" AND account_id=?");
            args.add(accountId);
        }
        if (category != null && !category.isEmpty()) {
            where.append(" AND category=?");
            args.add(category);
        }
        if (actionableOnly) {
            where.append(" AND actionable=1");
        }
        if (search != null && !search.trim().isEmpty()) {
            where.append(" AND (sender LIKE ? OR subject LIKE ? OR snippet LIKE ?)");
            String q = "%" + search.trim() + "%";
            args.add(q); args.add(q); args.add(q);
        }

        List<MailItem> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query(
                "mails", null, where.toString(), args.toArray(new String[0]),
                null, null, "received_at DESC", String.valueOf(limit))) {
            while (c.moveToNext()) {
                MailItem m = new MailItem();
                m.remoteId = c.getString(c.getColumnIndexOrThrow("remote_id"));
                m.accountId = c.getString(c.getColumnIndexOrThrow("account_id"));
                m.from = c.getString(c.getColumnIndexOrThrow("sender"));
                m.subject = c.getString(c.getColumnIndexOrThrow("subject"));
                m.snippet = c.getString(c.getColumnIndexOrThrow("snippet"));
                m.receivedAt = c.getLong(c.getColumnIndexOrThrow("received_at"));
                m.unread = c.getInt(c.getColumnIndexOrThrow("unread")) == 1;
                m.actionable = c.getInt(c.getColumnIndexOrThrow("actionable")) == 1;
                m.category = c.getString(c.getColumnIndexOrThrow("category"));
                out.add(m);
            }
        }
        return out;
    }

    public int countAll() { return scalar("SELECT COUNT(*) FROM mails"); }
    public int countActionable() { return scalar("SELECT COUNT(*) FROM mails WHERE actionable=1"); }
    public int countUnread() { return scalar("SELECT COUNT(*) FROM mails WHERE unread=1"); }

    public int countCategory(String category) {
        try (Cursor c = getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM mails WHERE category=?", new String[]{category})) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private int scalar(String sql) {
        try (Cursor c = getReadableDatabase().rawQuery(sql, null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public void deleteAccount(String accountId) {
        getWritableDatabase().delete("mails", "account_id=?", new String[]{accountId});
    }
}
