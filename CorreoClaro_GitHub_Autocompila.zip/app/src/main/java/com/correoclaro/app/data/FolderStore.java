package com.correoclaro.app.data;

import com.correoclaro.app.model.MailFolder;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class FolderStore {
    private final SecurePrefs secure;

    public FolderStore(SecurePrefs secure) {
        this.secure = secure;
    }

    private String key(String accountId) {
        return "folders_" + accountId;
    }

    public void save(String accountId, List<MailFolder> folders) {
        try {
            JSONArray arr = new JSONArray();
            for (MailFolder f : folders) arr.put(f.toJson());
            secure.put(key(accountId), arr.toString());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public List<MailFolder> all(String accountId) {
        List<MailFolder> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(secure.get(key(accountId), "[]"));
            for (int i = 0; i < arr.length(); i++) out.add(MailFolder.fromJson(arr.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    public MailFolder byName(String accountId, String name) {
        for (MailFolder f : all(accountId)) {
            if (f.name != null && f.name.equals(name)) return f;
        }
        return null;
    }

    public void clear(String accountId) {
        secure.remove(key(accountId));
    }
}
