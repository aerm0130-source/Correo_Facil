package com.correoclaro.app.provider;

import com.correoclaro.app.core.MailClassifier;
import com.correoclaro.app.model.MailItem;
import com.correoclaro.app.net.HttpJson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class GmailConnector {


    public static void moveToTrash(String accessToken, String messageId) throws Exception {
        HttpJson.post("https://gmail.googleapis.com/gmail/v1/users/me/messages/" +
                messageId + "/trash", accessToken, "{}");
    }

    public static String fetchEmail(String accessToken) throws Exception {
        JSONObject p = HttpJson.get("https://gmail.googleapis.com/gmail/v1/users/me/profile", accessToken);
        return p.optString("emailAddress");
    }

    public static List<MailItem> sync(String accountId, String accessToken) throws Exception {
        List<MailItem> out = new ArrayList<>();
        JSONObject list = HttpJson.get(
                "https://gmail.googleapis.com/gmail/v1/users/me/messages?maxResults=50&q=" +
                        URLEncoder.encode("newer_than:30d", StandardCharsets.UTF_8), accessToken);
        JSONArray arr = list.optJSONArray("messages");
        if (arr == null) return out;

        for (int i = 0; i < arr.length(); i++) {
            String id = arr.getJSONObject(i).optString("id");
            if (id.isEmpty()) continue;
            JSONObject msg = HttpJson.get(
                    "https://gmail.googleapis.com/gmail/v1/users/me/messages/" + id +
                            "?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date",
                    accessToken);

            MailItem m = new MailItem();
            m.remoteId = id;
            m.accountId = accountId;
            m.snippet = msg.optString("snippet");
            m.receivedAt = parseLong(msg.optString("internalDate"));

            JSONArray labels = msg.optJSONArray("labelIds");
            m.unread = contains(labels, "UNREAD");

            JSONObject payload = msg.optJSONObject("payload");
            JSONArray headers = payload == null ? null : payload.optJSONArray("headers");
            m.from = header(headers, "From");
            m.subject = header(headers, "Subject");
            MailClassifier.classify(m);
            out.add(m);
        }
        return out;
    }

    private static String header(JSONArray arr, String name) {
        if (arr == null) return "";
        for (int i = 0; i < arr.length(); i++) {
            JSONObject h = arr.optJSONObject(i);
            if (h != null && name.equalsIgnoreCase(h.optString("name"))) return h.optString("value");
        }
        return "";
    }

    private static boolean contains(JSONArray arr, String value) {
        if (arr == null) return false;
        for (int i = 0; i < arr.length(); i++) if (value.equals(arr.optString(i))) return true;
        return false;
    }

    private static long parseLong(String s) {
        try { return Long.parseLong(s); } catch (Exception e) { return System.currentTimeMillis(); }
    }
}
