package com.correoclaro.app.provider;

import com.correoclaro.app.core.MailClassifier;
import com.correoclaro.app.model.MailFolder;
import com.correoclaro.app.model.MailItem;
import com.sun.mail.imap.IMAPFolder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class ImapConnector {

    public static List<MailFolder> listFolders(JSONObject cfg, String password) throws Exception {
        Store store = connectImap(cfg, password);
        List<MailFolder> out = new ArrayList<>();
        try {
            Folder[] folders = store.getDefaultFolder().list("*");
            for (Folder f : folders) {
                if ((f.getType() & Folder.HOLDS_MESSAGES) == 0) continue;
                MailFolder mf = new MailFolder();
                mf.name = f.getFullName();
                mf.special = specialType(f);
                mf.displayName = displayName(mf.name, mf.special);
                out.add(mf);
            }
            boolean inbox = false;
            for (MailFolder f : out) if ("INBOX".equalsIgnoreCase(f.name)) inbox = true;
            if (!inbox) {
                MailFolder f = new MailFolder();
                f.name = "INBOX";
                f.special = "INBOX";
                f.displayName = "Entrada";
                out.add(0, f);
            }
            out.sort((a, b) -> rank(a) == rank(b)
                    ? a.displayName.compareToIgnoreCase(b.displayName)
                    : Integer.compare(rank(a), rank(b)));
            return out;
        } finally {
            try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static List<MailItem> sync(String accountId, JSONObject cfg, String password) throws Exception {
        return syncFolder(accountId, cfg, password, "INBOX", 100);
    }

    public static List<MailItem> syncFolder(String accountId, JSONObject cfg, String password,
                                            String folderName, int limit) throws Exception {
        Store store = connectImap(cfg, password);
        Folder folder = null;
        List<MailItem> out = new ArrayList<>();
        try {
            folder = store.getFolder(folderName);
            if (!folder.exists()) throw new IllegalStateException("La carpeta ya no existe: " + folderName);
            folder.open(Folder.READ_ONLY);
            int count = folder.getMessageCount();
            if (count <= 0) return out;
            int start = Math.max(1, count - Math.max(1, limit) + 1);
            Message[] messages = folder.getMessages(start, count);
            for (int i = messages.length - 1; i >= 0; i--) {
                Message msg = messages[i];
                MailItem m = new MailItem();
                m.remoteId = uid(folder, msg);
                m.accountId = accountId;
                m.folder = folderName;
                m.subject = safe(msg.getSubject());
                m.from = formatAddresses(msg.getFrom());
                Date d = msg.getReceivedDate();
                if (d == null) d = msg.getSentDate();
                m.receivedAt = d == null ? System.currentTimeMillis() : d.getTime();
                m.unread = !msg.isSet(Flags.Flag.SEEN);
                m.snippet = ""; // ligero: el cuerpo solo se descarga al abrir el correo
                MailClassifier.classify(m);
                out.add(m);
            }
            return out;
        } finally {
            if (folder != null && folder.isOpen()) try { folder.close(false); } catch (Exception ignored) {}
            try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static String fetchBody(JSONObject cfg, String password, String folderName, String remoteId) throws Exception {
        Store store = connectImap(cfg, password);
        Folder folder = null;
        try {
            folder = store.getFolder(folderName);
            folder.open(Folder.READ_ONLY);
            Message msg = findByUid(folder, remoteId);
            if (msg == null) throw new IllegalStateException("El correo ya no existe en esa carpeta");
            String body = extractText(msg);
            if (body == null || body.trim().isEmpty()) return "(Sin contenido de texto)";
            if (body.length() > 40000) body = body.substring(0, 40000) + "\n\n[Contenido recortado para mantener la app ligera]";
            return body.trim();
        } finally {
            if (folder != null && folder.isOpen()) try { folder.close(false); } catch (Exception ignored) {}
            try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static void createFolder(JSONObject cfg, String password, String name) throws Exception {
        Store store = connectImap(cfg, password);
        try {
            Folder folder = store.getFolder(name);
            if (folder.exists()) throw new IllegalStateException("La carpeta ya existe");
            if (!folder.create(Folder.HOLDS_MESSAGES)) throw new IllegalStateException("El servidor no permitió crear la carpeta");
        } finally {
            try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static void renameFolder(JSONObject cfg, String password, String oldName, String newName) throws Exception {
        Store store = connectImap(cfg, password);
        try {
            Folder oldFolder = store.getFolder(oldName);
            Folder newFolder = store.getFolder(newName);
            if (!oldFolder.exists()) throw new IllegalStateException("La carpeta ya no existe");
            if (newFolder.exists()) throw new IllegalStateException("Ya existe una carpeta con ese nombre");
            if (!oldFolder.renameTo(newFolder)) throw new IllegalStateException("El servidor no permitió renombrar la carpeta");
        } finally {
            try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static void deleteFolder(JSONObject cfg, String password, String name) throws Exception {
        Store store = connectImap(cfg, password);
        try {
            Folder folder = store.getFolder(name);
            if (!folder.exists()) return;
            if (!folder.delete(true)) throw new IllegalStateException("El servidor no permitió eliminar la carpeta");
        } finally {
            try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static void moveMessages(JSONObject cfg, String password, String sourceFolder,
                                    List<String> remoteIds, String destinationFolder) throws Exception {
        if (remoteIds == null || remoteIds.isEmpty()) return;
        Store store = connectImap(cfg, password);
        Folder source = null;
        try {
            source = store.getFolder(sourceFolder);
            Folder destination = store.getFolder(destinationFolder);
            if (!destination.exists()) throw new IllegalStateException("La carpeta destino no existe");
            source.open(Folder.READ_WRITE);
            List<Message> found = new ArrayList<>();
            for (String id : remoteIds) {
                Message m = findByUid(source, id);
                if (m != null) found.add(m);
            }
            if (found.isEmpty()) return;
            Message[] arr = found.toArray(new Message[0]);
            source.copyMessages(arr, destination);
            for (Message m : arr) m.setFlag(Flags.Flag.DELETED, true);
            source.close(true);
            source = null;
        } finally {
            if (source != null && source.isOpen()) try { source.close(false); } catch (Exception ignored) {}
            try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static void moveToTrash(JSONObject cfg, String password, String sourceFolder,
                                   List<String> remoteIds) throws Exception {
        Store store = connectImap(cfg, password);
        try {
            Folder trash = findSpecialFolder(store, "TRASH");
            if (trash == null) throw new IllegalStateException("No pude localizar la Papelera del servidor");
            // cerrar este Store y reutilizar el método normal con una conexión limpia
            String trashName = trash.getFullName();
            try { store.close(); } catch (Exception ignored) {}
            moveMessages(cfg, password, sourceFolder, remoteIds, trashName);
            return;
        } finally {
            if (store.isConnected()) try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static void setSeen(JSONObject cfg, String password, String folderName,
                               List<String> remoteIds, boolean seen) throws Exception {
        if (remoteIds == null || remoteIds.isEmpty()) return;
        Store store = connectImap(cfg, password);
        Folder folder = null;
        try {
            folder = store.getFolder(folderName);
            folder.open(Folder.READ_WRITE);
            for (String id : remoteIds) {
                Message m = findByUid(folder, id);
                if (m != null) m.setFlag(Flags.Flag.SEEN, seen);
            }
        } finally {
            if (folder != null && folder.isOpen()) try { folder.close(false); } catch (Exception ignored) {}
            try { store.close(); } catch (Exception ignored) {}
        }
    }

    public static void send(JSONObject cfg, String password, String from,
                            String to, String cc, String bcc, String subject,
                            String body, String signature) throws Exception {
        String smtpHost = cfg.optString("smtpHost");
        int smtpPort = cfg.optInt("smtpPort", 465);
        String smtpSecurity = cfg.optString("smtpSecurity", "SSL");
        String smtpUser = cfg.optString("smtpUsername", cfg.optString("username", from));
        if (smtpHost.isEmpty()) throw new IllegalStateException("Falta configurar el servidor de salida SMTP");

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.connectiontimeout", "15000");
        props.put("mail.smtp.timeout", "20000");
        props.put("mail.smtp.writetimeout", "20000");
        if ("STARTTLS".equalsIgnoreCase(smtpSecurity)) {
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.starttls.required", "true");
        } else {
            props.put("mail.smtp.ssl.enable", "true");
        }

        Session session = Session.getInstance(props);
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(from));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to, false));
        if (cc != null && !cc.trim().isEmpty()) message.setRecipients(Message.RecipientType.CC, InternetAddress.parse(cc, false));
        if (bcc != null && !bcc.trim().isEmpty()) message.setRecipients(Message.RecipientType.BCC, InternetAddress.parse(bcc, false));
        message.setSubject(subject == null ? "" : subject, "UTF-8");
        String finalBody = body == null ? "" : body;
        if (signature != null && !signature.trim().isEmpty()) finalBody += "\n\n" + signature.trim();
        message.setText(finalBody, "UTF-8");
        message.setSentDate(new Date());
        message.saveChanges();

        Transport transport = session.getTransport("smtp");
        try {
            transport.connect(smtpHost, smtpPort, smtpUser, password);
            transport.sendMessage(message, message.getAllRecipients());
        } finally {
            try { transport.close(); } catch (Exception ignored) {}
        }

        // Gmail guarda automáticamente lo enviado por SMTP. En otros proveedores intentamos copiar a Enviados.
        if ("gmail".equalsIgnoreCase(cfg.optString("preset"))) return;
        try {
            Store store = connectImap(cfg, password);
            try {
                Folder sent = findSpecialFolder(store, "SENT");
                if (sent != null && sent.exists()) {
                    message.setFlag(Flags.Flag.SEEN, true);
                    sent.appendMessages(new Message[]{message});
                }
            } finally {
                try { store.close(); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    private static Store connectImap(JSONObject cfg, String password) throws Exception {
        String host = cfg.getString("host");
        int port = cfg.optInt("port", 993);
        String security = cfg.optString("imapSecurity", cfg.optBoolean("ssl", true) ? "SSL" : "STARTTLS");
        boolean ssl = "SSL".equalsIgnoreCase(security);
        String username = cfg.getString("username");
        String protocol = ssl ? "imaps" : "imap";
        Session session = Session.getInstance(imapProperties(security));
        Store store = session.getStore(protocol);
        store.connect(host, port, username, password);
        return store;
    }

    private static Properties imapProperties(String security) {
        boolean ssl = "SSL".equalsIgnoreCase(security);
        String protocol = ssl ? "imaps" : "imap";
        Properties props = new Properties();
        props.put("mail.store.protocol", protocol);
        props.put("mail." + protocol + ".connectiontimeout", "15000");
        props.put("mail." + protocol + ".timeout", "20000");
        props.put("mail." + protocol + ".writetimeout", "20000");
        props.put("mail." + protocol + ".ssl.enable", String.valueOf(ssl));
        if (!ssl) {
            props.put("mail.imap.starttls.enable", "true");
            props.put("mail.imap.starttls.required", "true");
        }
        return props;
    }

    private static String uid(Folder folder, Message msg) {
        if (folder instanceof IMAPFolder) {
            try { return String.valueOf(((IMAPFolder) folder).getUID(msg)); }
            catch (Exception ignored) {}
        }
        return String.valueOf(msg.getMessageNumber());
    }

    private static Message findByUid(Folder folder, String remoteId) {
        if (folder instanceof IMAPFolder) {
            try { return ((IMAPFolder) folder).getMessageByUID(Long.parseLong(remoteId)); }
            catch (Exception ignored) {}
        }
        try {
            int n = Integer.parseInt(remoteId);
            if (n >= 1 && n <= folder.getMessageCount()) return folder.getMessage(n);
        } catch (Exception ignored) {}
        return null;
    }

    private static Folder findSpecialFolder(Store store, String type) throws Exception {
        Folder fallback = null;
        for (Folder f : store.getDefaultFolder().list("*")) {
            String special = specialType(f);
            if (type.equals(special)) return f;
            String n = f.getFullName().toLowerCase(Locale.ROOT);
            if ("TRASH".equals(type) && (n.equals("trash") || n.endsWith("/trash") || n.contains("papelera") || n.contains("deleted items"))) fallback = f;
            if ("SENT".equals(type) && (n.equals("sent") || n.endsWith("/sent") || n.contains("enviados") || n.contains("sent mail"))) fallback = f;
        }
        return fallback;
    }

    private static String specialType(Folder f) {
        if ("INBOX".equalsIgnoreCase(f.getFullName())) return "INBOX";
        if (f instanceof IMAPFolder) {
            try {
                String[] attrs = ((IMAPFolder) f).getAttributes();
                if (attrs != null) for (String a : attrs) {
                    if ("\\Trash".equalsIgnoreCase(a)) return "TRASH";
                    if ("\\Sent".equalsIgnoreCase(a)) return "SENT";
                    if ("\\Drafts".equalsIgnoreCase(a)) return "DRAFTS";
                    if ("\\Junk".equalsIgnoreCase(a) || "\\Spam".equalsIgnoreCase(a)) return "JUNK";
                    if ("\\Archive".equalsIgnoreCase(a) || "\\All".equalsIgnoreCase(a)) return "ARCHIVE";
                }
            } catch (Exception ignored) {}
        }
        String n = f.getFullName().toLowerCase(Locale.ROOT);
        if (n.contains("trash") || n.contains("papelera") || n.contains("deleted items")) return "TRASH";
        if (n.contains("sent") || n.contains("enviados")) return "SENT";
        if (n.contains("draft") || n.contains("borrador")) return "DRAFTS";
        if (n.contains("spam") || n.contains("junk")) return "JUNK";
        return "";
    }

    private static String displayName(String name, String special) {
        if ("INBOX".equals(special)) return "Entrada";
        if ("SENT".equals(special)) return "Enviados";
        if ("DRAFTS".equals(special)) return "Borradores";
        if ("TRASH".equals(special)) return "Papelera";
        if ("JUNK".equals(special)) return "Spam";
        if ("ARCHIVE".equals(special)) return "Archivo";
        return name;
    }

    private static int rank(MailFolder f) {
        if ("INBOX".equals(f.special)) return 0;
        if ("SENT".equals(f.special)) return 1;
        if ("DRAFTS".equals(f.special)) return 2;
        if ("ARCHIVE".equals(f.special)) return 3;
        if ("JUNK".equals(f.special)) return 90;
        if ("TRASH".equals(f.special)) return 99;
        return 10;
    }

    private static String extractText(Object part) throws Exception {
        if (part instanceof Message) {
            Message m = (Message) part;
            if (m.isMimeType("text/plain")) return String.valueOf(m.getContent());
            if (m.isMimeType("text/html")) return cleanHtml(String.valueOf(m.getContent()));
            if (m.isMimeType("multipart/*")) return extractMultipart((Multipart) m.getContent());
            return "";
        }
        if (part instanceof BodyPart) {
            BodyPart b = (BodyPart) part;
            String disposition = b.getDisposition();
            if (disposition != null && disposition.equalsIgnoreCase(javax.mail.Part.ATTACHMENT)) return "";
            if (b.isMimeType("text/plain")) return String.valueOf(b.getContent());
            if (b.isMimeType("text/html")) return cleanHtml(String.valueOf(b.getContent()));
            if (b.isMimeType("multipart/*")) return extractMultipart((Multipart) b.getContent());
        }
        return "";
    }

    private static String extractMultipart(Multipart mp) throws Exception {
        String html = "";
        for (int i = 0; i < mp.getCount(); i++) {
            BodyPart b = mp.getBodyPart(i);
            String text = extractText(b);
            if (b.isMimeType("text/plain") && text != null && !text.trim().isEmpty()) return text;
            if (html.isEmpty() && text != null && !text.trim().isEmpty()) html = text;
        }
        return html;
    }

    private static String cleanHtml(String html) {
        if (html == null) return "";
        return html.replaceAll("(?is)<(script|style).*?>.*?</\\1>", " ")
                .replaceAll("(?s)<[^>]*>", " ")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replaceAll("[ \\t\\x0B\\f\\r]+", " ")
                .replaceAll("\\n{3,}", "\\n\\n");
    }

    private static String safe(String s) { return s == null ? "" : s; }

    private static String formatAddresses(Address[] addresses) {
        if (addresses == null || addresses.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (Address a : addresses) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(a.toString());
        }
        return sb.toString();
    }
}
