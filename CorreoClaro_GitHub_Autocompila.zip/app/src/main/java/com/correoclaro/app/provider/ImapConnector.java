package com.correoclaro.app.provider;

import com.correoclaro.app.core.MailClassifier;
import com.correoclaro.app.model.MailItem;
import com.sun.mail.imap.IMAPFolder;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;

public class ImapConnector {

    public static List<MailItem> sync(String accountId, JSONObject cfg, String password) throws Exception {
        String host = cfg.getString("host");
        int port = cfg.optInt("port", 993);
        boolean ssl = cfg.optBoolean("ssl", true);
        String username = cfg.getString("username");

        Properties props = properties(ssl);
        String protocol = ssl ? "imaps" : "imap";
        Session session = Session.getInstance(props);
        Store store = session.getStore(protocol);
        Folder inbox = null;
        List<MailItem> out = new ArrayList<>();

        try {
            store.connect(host, port, username, password);
            inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);

            int count = inbox.getMessageCount();
            if (count <= 0) return out;
            int start = Math.max(1, count - 99);
            Message[] messages = inbox.getMessages(start, count);

            for (int i = messages.length - 1; i >= 0; i--) {
                Message msg = messages[i];
                MailItem m = new MailItem();
                if (inbox instanceof IMAPFolder) {
                    m.remoteId = String.valueOf(((IMAPFolder) inbox).getUID(msg));
                } else {
                    m.remoteId = String.valueOf(msg.getMessageNumber());
                }
                m.accountId = accountId;
                m.subject = safe(msg.getSubject());
                m.from = formatAddresses(msg.getFrom());
                Date d = msg.getReceivedDate();
                if (d == null) d = msg.getSentDate();
                m.receivedAt = d == null ? System.currentTimeMillis() : d.getTime();
                m.unread = !msg.isSet(Flags.Flag.SEEN);
                m.snippet = "";
                MailClassifier.classify(m);
                out.add(m);
            }
        } finally {
            if (inbox != null && inbox.isOpen()) try { inbox.close(false); } catch (Exception ignored) {}
            if (store.isConnected()) try { store.close(); } catch (Exception ignored) {}
        }
        return out;
    }

    public static void moveToTrash(JSONObject cfg, String password, String remoteId) throws Exception {
        String host = cfg.getString("host");
        int port = cfg.optInt("port", 993);
        boolean ssl = cfg.optBoolean("ssl", true);
        String username = cfg.getString("username");

        String protocol = ssl ? "imaps" : "imap";
        Session session = Session.getInstance(properties(ssl));
        Store store = session.getStore(protocol);
        Folder inbox = null;
        Folder trash = null;

        try {
            store.connect(host, port, username, password);
            inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_WRITE);

            Message msg = null;
            if (inbox instanceof IMAPFolder) {
                try {
                    long uid = Long.parseLong(remoteId);
                    msg = ((IMAPFolder) inbox).getMessageByUID(uid);
                } catch (Exception ignored) {}
            }
            if (msg == null) {
                try {
                    int n = Integer.parseInt(remoteId);
                    if (n >= 1 && n <= inbox.getMessageCount()) msg = inbox.getMessage(n);
                } catch (Exception ignored) {}
            }
            if (msg == null) throw new IllegalStateException("El correo ya no existe en INBOX");

            trash = findTrash(store);
            if (trash == null) throw new IllegalStateException("No pude localizar la carpeta Papelera del servidor");

            if (!trash.exists()) throw new IllegalStateException("La carpeta Papelera no existe");
            inbox.copyMessages(new Message[]{msg}, trash);
            msg.setFlag(Flags.Flag.DELETED, true);
            inbox.expunge();
        } finally {
            if (trash != null && trash.isOpen()) try { trash.close(false); } catch (Exception ignored) {}
            if (inbox != null && inbox.isOpen()) try { inbox.close(false); } catch (Exception ignored) {}
            if (store.isConnected()) try { store.close(); } catch (Exception ignored) {}
        }
    }

    private static Folder findTrash(Store store) {
        try {
            Folder[] all = store.getDefaultFolder().list("*");
            Folder fallback = null;
            for (Folder f : all) {
                if (f instanceof IMAPFolder) {
                    try {
                        String[] attrs = ((IMAPFolder) f).getAttributes();
                        if (attrs != null) {
                            for (String a : attrs) {
                                if ("\\Trash".equalsIgnoreCase(a)) return f;
                            }
                        }
                    } catch (Exception ignored) {}
                }
                String n = f.getFullName().toLowerCase(Locale.ROOT);
                if (n.equals("trash") || n.endsWith("/trash") || n.contains("papelera")
                        || n.contains("deleted items") || n.contains("elementos eliminados")) {
                    fallback = f;
                }
            }
            return fallback;
        } catch (Exception e) {
            return null;
        }
    }

    private static Properties properties(boolean ssl) {
        String protocol = ssl ? "imaps" : "imap";
        Properties props = new Properties();
        props.put("mail.store.protocol", protocol);
        props.put("mail." + protocol + ".connectiontimeout", "15000");
        props.put("mail." + protocol + ".timeout", "20000");
        props.put("mail." + protocol + ".writetimeout", "20000");
        props.put("mail." + protocol + ".ssl.enable", String.valueOf(ssl));
        return props;
    }

    private static String safe(String s) { return s == null ? "" : s; }

    private static String formatAddresses(Address[] addresses) {
        if (addresses == null || addresses.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (Address a : addresses) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(a.toString());
        }
        return sb.toString();
    }
}
