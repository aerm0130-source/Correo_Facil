package com.correoclaro.app.provider;

import com.correoclaro.app.core.MailClassifier;
import com.correoclaro.app.model.MailItem;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;

public class ImapConnector {

    public static List<MailItem> sync(String accountId, JSONObject cfg, String password) throws Exception {
        String host = cfg.getString("host");
        int port = cfg.optInt("port", 993);
        boolean ssl = cfg.optBoolean("ssl", true);
        String username = cfg.getString("username");

        Properties props = new Properties();
        String protocol = ssl ? "imaps" : "imap";
        props.put("mail.store.protocol", protocol);
        props.put("mail." + protocol + ".connectiontimeout", "15000");
        props.put("mail." + protocol + ".timeout", "20000");
        props.put("mail." + protocol + ".writetimeout", "20000");
        props.put("mail." + protocol + ".ssl.enable", String.valueOf(ssl));

        Session session = Session.getInstance(props);
        Store store = session.getStore(protocol);
        Folder inbox = null;
        List<MailItem> out = new ArrayList<>();

        try {
            store.connect(host, port, username, password);
            inbox = store.getFolder("INBOX");
            inbox.open(Folder.READ_ONLY);

            int count = inbox.getMessageCount();
            int start = Math.max(1, count - 49);
            Message[] messages = inbox.getMessages(start, count);

            for (int i = messages.length - 1; i >= 0; i--) {
                Message msg = messages[i];
                MailItem m = new MailItem();
                m.remoteId = String.valueOf(msg.getMessageNumber());
                m.accountId = accountId;
                m.subject = safe(msg.getSubject());
                m.from = formatAddresses(msg.getFrom());
                Date d = msg.getReceivedDate();
                if (d == null) d = msg.getSentDate();
                m.receivedAt = d == null ? System.currentTimeMillis() : d.getTime();
                m.unread = !msg.isSet(Flags.Flag.SEEN);
                m.snippet = "";
                MailClassifier.classify(m);
                out.add(m);
            }
        } finally {
            if (inbox != null && inbox.isOpen()) try { inbox.close(false); } catch (Exception ignored) {}
            if (store.isConnected()) try { store.close(); } catch (Exception ignored) {}
        }

        return out;
    }

    private static String safe(String s) { return s == null ? "" : s; }

    private static String formatAddresses(Address[] addresses) {
        if (addresses == null || addresses.length == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (Address a : addresses) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(a.toString());
        }
        return sb.toString();
    }
}
