package com.correoclaro.app.data;

import com.correoclaro.app.model.MailItem;
import com.correoclaro.app.model.MailRule;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class RuleStore {
    private static final String KEY = "mail_rules";
    private final SecurePrefs secure;

    public RuleStore(SecurePrefs secure) {
        this.secure = secure;
    }

    public List<MailRule> all() {
        List<MailRule> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(secure.get(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) out.add(MailRule.fromJson(arr.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    public MailRule save(MailRule rule) {
        if (rule.id == null || rule.id.isEmpty()) rule.id = UUID.randomUUID().toString();
        List<MailRule> list = all();
        boolean replaced = false;
        for (int i = 0; i < list.size(); i++) {
            if (rule.id.equals(list.get(i).id)) {
                list.set(i, rule);
                replaced = true;
                break;
            }
        }
        if (!replaced) list.add(rule);
        persist(list);
        return rule;
    }

    public void delete(String id) {
        List<MailRule> list = all();
        list.removeIf(r -> id.equals(r.id));
        persist(list);
    }

    /** Devuelve la carpeta destino de la primera regla del usuario que coincide. */
    public String match(MailItem m) {
        return match(m, all());
    }

    /** Versión rápida: recibe las reglas ya cargadas para no descifrar/parsear JSON por cada correo. */
    public String match(MailItem m, List<MailRule> rules) {
        if (rules == null || rules.isEmpty()) return "";
        for (MailRule r : rules) {
            if (!r.enabled) continue;
            if (r.accountId == null || r.accountId.isEmpty() || !r.accountId.equals(m.accountId)) continue;

            String value;
            if ("Asunto".equals(r.field)) value = m.subject;
            else if ("Remitente o asunto".equals(r.field)) value = safe(m.from) + " " + safe(m.subject);
            else if ("Dominio del remitente".equals(r.field)) value = senderDomain(m.from);
            else value = m.from;

            if (matches(value, r.contains, r.operator)) {
                return r.category == null ? "" : r.category;
            }
        }
        return "";
    }

    private boolean matches(String value, String expected, String operator) {
        String a = safe(value).trim().toLowerCase(Locale.ROOT);
        String b = safe(expected).trim().toLowerCase(Locale.ROOT);
        if (b.isEmpty()) return false;

        String op = safe(operator);
        if ("No contiene".equals(op)) return !a.contains(b);
        if ("Es igual a".equals(op)) return a.equals(b);
        if ("Empieza con".equals(op)) return a.startsWith(b);
        if ("Termina con".equals(op)) return a.endsWith(b);
        if ("Dominio es".equals(op)) return senderDomain(a).equals(normalizeDomain(b));
        if ("Uno de".equals(op)) {
            String[] parts = b.split("[,;]");
            for (String p : parts) {
                String v = p.trim();
                if (!v.isEmpty() && (a.equals(v) || a.contains(v))) return true;
            }
            return false;
        }
        return a.contains(b); // Contiene y compatibilidad con reglas anteriores
    }

    private String senderDomain(String from) {
        String s = safe(from).trim().toLowerCase(Locale.ROOT);
        int lt = s.indexOf('<');
        int gt = s.indexOf('>');
        if (lt >= 0 && gt > lt) s = s.substring(lt + 1, gt).trim();
        int at = s.lastIndexOf('@');
        if (at >= 0 && at + 1 < s.length()) return normalizeDomain(s.substring(at + 1));
        return normalizeDomain(s);
    }

    private String normalizeDomain(String s) {
        String x = safe(s).trim().toLowerCase(Locale.ROOT);
        if (x.startsWith("@")) x = x.substring(1);
        if (x.startsWith("www.")) x = x.substring(4);
        return x;
    }

    private String safe(String s) { return s == null ? "" : s; }

    private void persist(List<MailRule> list) {
        try {
            JSONArray arr = new JSONArray();
            for (MailRule r : list) arr.put(r.toJson());
            secure.put(KEY, arr.toString());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
