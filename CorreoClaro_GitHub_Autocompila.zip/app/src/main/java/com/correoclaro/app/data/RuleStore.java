package com.correoclaro.app.data;

import com.correoclaro.app.model.MailItem;
import com.correoclaro.app.model.MailRule;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class RuleStore {
    private static final String KEY = "mail_rules";
    private final SecurePrefs secure;

    public RuleStore(SecurePrefs secure) {
        this.secure = secure;
    }

    public List<MailRule> all() {
        List<MailRule> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(secure.get(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) out.add(MailRule.fromJson(arr.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    public MailRule save(MailRule rule) {
        if (rule.id == null || rule.id.isEmpty()) rule.id = UUID.randomUUID().toString();
        List<MailRule> list = all();
        boolean replaced = false;
        for (int i = 0; i < list.size(); i++) {
            if (rule.id.equals(list.get(i).id)) {
                list.set(i, rule);
                replaced = true;
                break;
            }
        }
        if (!replaced) list.add(rule);
        persist(list);
        return rule;
    }

    public void delete(String id) {
        List<MailRule> list = all();
        list.removeIf(r -> id.equals(r.id));
        persist(list);
    }

    /** Devuelve la carpeta destino de la primera regla del usuario que coincide. */
    public String match(MailItem m) {
        for (MailRule r : all()) {
            if (!r.enabled) continue;
            if (r.accountId == null || r.accountId.isEmpty() || !r.accountId.equals(m.accountId)) continue;
            String value;
            if ("Asunto".equals(r.field)) value = m.subject;
            else if ("Remitente o asunto".equals(r.field)) value = safe(m.from) + " " + safe(m.subject);
            else value = m.from;

            String a = safe(value).toLowerCase(Locale.ROOT);
            String b = safe(r.contains).toLowerCase(Locale.ROOT).trim();
            if (!b.isEmpty() && a.contains(b)) return r.category == null ? "" : r.category;
        }
        return "";
    }

    private String safe(String s) { return s == null ? "" : s; }

    private void persist(List<MailRule> list) {
        try {
            JSONArray arr = new JSONArray();
            for (MailRule r : list) arr.put(r.toJson());
            secure.put(KEY, arr.toString());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
