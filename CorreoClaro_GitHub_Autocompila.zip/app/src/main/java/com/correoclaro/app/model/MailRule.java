package com.correoclaro.app.model;

import org.json.JSONException;
import org.json.JSONObject;

public class MailRule {
    public String id;
    public String name;
    public String accountId;
    public String field;
    public String contains;
    public String category;
    public boolean enabled = true;

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("accountId", accountId == null ? "" : accountId);
        o.put("field", field);
        o.put("contains", contains);
        o.put("category", category);
        o.put("enabled", enabled);
        return o;
    }

    public static MailRule fromJson(JSONObject o) {
        MailRule r = new MailRule();
        r.id = o.optString("id");
        r.name = o.optString("name");
        r.accountId = o.optString("accountId");
        r.field = o.optString("field", "Remitente");
        r.contains = o.optString("contains");
        r.category = o.optString("category", "Otros");
        r.enabled = o.optBoolean("enabled", true);
        return r;
    }
}
