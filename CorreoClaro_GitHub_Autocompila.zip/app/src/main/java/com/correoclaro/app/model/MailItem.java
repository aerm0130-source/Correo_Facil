package com.correoclaro.app.model;

public class MailItem {
    public String remoteId;
    public String accountId;
    public String from;
    public String subject;
    public String snippet;
    public long receivedAt;
    public boolean unread;
    public boolean actionable;
    public String category;
    public String folder;
}
