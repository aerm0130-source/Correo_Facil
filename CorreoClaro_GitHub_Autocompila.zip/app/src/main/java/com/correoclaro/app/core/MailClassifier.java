package com.correoclaro.app.core;

import com.correoclaro.app.model.MailItem;

/**
 * Correo Facil 1.2 no clasifica ni decide por el usuario.
 * Las reglas y carpetas son exclusivamente creadas por el usuario.
 */
public class MailClassifier {
    public static final String[] CATEGORIES = new String[0];

    public static void classify(MailItem m) {
        m.actionable = false;
        m.category = "";
        if (m.folder == null || m.folder.isEmpty()) m.folder = "INBOX";
    }
}
