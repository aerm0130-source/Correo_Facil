package com.correoclaro.app.core;

import com.correoclaro.app.model.MailItem;

import java.util.Locale;

public class MailClassifier {

    public static final String[] CATEGORIES = new String[] {
            "Clientes", "Facturas", "Bancos", "Autoridades", "Proveedores",
            "Compras", "Suscripciones", "Publicidad", "Seguridad", "Otros"
    };

    public static void classify(MailItem m) {
        String text = norm(m.from + " " + m.subject + " " + m.snippet);

        m.actionable = hasAny(text,
                "favor de", "por favor", "podrias", "podría", "puedes", "puede confirmar",
                "confirmar", "revisar", "requiero", "requerimos", "solicito", "solicitamos",
                "pendiente", "urgente", "respuesta", "necesitamos", "necesito",
                "could you", "please confirm", "action required", "approval");

        if (hasAny(text, "sat.gob", "imss.gob", "infonavit", "sateg", "hacienda",
                "secretaria de finanzas", "gob.mx", "buzon tributario", "buzón tributario")) {
            m.category = "Autoridades";
        } else if (hasAny(text, "factura", "cfdi", "xml", "invoice", "complemento de pago",
                "recibo fiscal", "nota de credito", "nota de crédito")) {
            m.category = "Facturas";
        } else if (hasAny(text, "bbva", "banamex", "citibanamex", "santander", "hsbc",
                "banorte", "banco", "spei", "transferencia", "estado de cuenta", "movimiento bancario")) {
            m.category = "Bancos";
        } else if (hasAny(text, "codigo de verificacion", "código de verificación", "otp",
                "security alert", "alerta de seguridad", "inicio de sesion", "inicio de sesión",
                "password", "contraseña", "acceso nuevo")) {
            m.category = "Seguridad";
        } else if (hasAny(text, "orden de compra", "purchase order", "cotizacion", "cotización",
                "proveedor", "supplier", "pedido de compra")) {
            m.category = "Proveedores";
        } else if (hasAny(text, "amazon", "mercado libre", "mercadolibre", "pedido enviado",
                "tu pedido", "shipment", "order confirmed", "compra realizada")) {
            m.category = "Compras";
        } else if (hasAny(text, "unsubscribe", "cancelar suscripcion", "cancelar suscripción",
                "newsletter", "boletin", "boletín")) {
            m.category = "Suscripciones";
        } else if (hasAny(text, "promocion", "promoción", "oferta", "descuento", "marketing",
                "black friday", "hot sale", "publicidad")) {
            m.category = "Publicidad";
        } else if (looksHuman(m.from) && !isNoReply(m.from)) {
            m.category = "Clientes";
        } else {
            m.category = "Otros";
        }
    }

    private static boolean looksHuman(String from) {
        if (from == null) return false;
        String s = norm(from);
        return s.contains("@") && !hasAny(s, "newsletter", "mailer", "notification", "notificacion", "noreply", "no-reply");
    }

    private static boolean isNoReply(String from) {
        return hasAny(norm(from), "noreply", "no-reply", "donotreply", "do-not-reply");
    }

    private static boolean hasAny(String text, String... terms) {
        for (String t : terms) if (text.contains(norm(t))) return true;
        return false;
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).trim();
    }
}
