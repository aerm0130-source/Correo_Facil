package com.correoclaro.app.model;

import org.json.JSONException;
import org.json.JSONObject;

public class MailAccount {
    public static final String GMAIL = "gmail";
    public static final String MICROSOFT = "microsoft";
    public static final String IMAP = "imap";

    public String id;
    public String provider;
    public String email;
    public String displayName;
    public String configJson;
    public long lastSync;

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("provider", provider);
        o.put("email", email);
        o.put("displayName", displayName);
        o.put("configJson", configJson == null ? "" : configJson);
        o.put("lastSync", lastSync);
        return o;
    }

    public static MailAccount fromJson(JSONObject o) {
        MailAccount a = new MailAccount();
        a.id = o.optString("id");
        a.provider = o.optString("provider");
        a.email = o.optString("email");
        a.displayName = o.optString("displayName");
        a.configJson = o.optString("configJson");
        a.lastSync = o.optLong("lastSync");
        return a;
    }
}
