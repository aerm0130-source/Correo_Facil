package com.correoclaro.app;

import android.accounts.Account;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentSender;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.correoclaro.app.core.MailClassifier;
import com.correoclaro.app.data.AccountStore;
import com.correoclaro.app.data.MailDatabase;
import com.correoclaro.app.model.MailAccount;
import com.correoclaro.app.model.MailItem;
import com.correoclaro.app.provider.GmailConnector;
import com.correoclaro.app.provider.ImapConnector;
import com.correoclaro.app.provider.MicrosoftConnector;
import com.correoclaro.app.ui.Ui;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;

import net.openid.appauth.AuthState;
import net.openid.appauth.AuthorizationException;
import net.openid.appauth.AuthorizationRequest.Builder;
import net.openid.appauth.AuthorizationResponse;
import net.openid.appauth.AuthorizationService;
import net.openid.appauth.AuthorizationServiceConfiguration;
import net.openid.appauth.ResponseTypeValues;
import net.openid.appauth.TokenResponse;

import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private AccountStore accountStore;
    private MailDatabase db;
    private LinearLayout content;
    private TextView title;
    private TextView subtitle;

    private String pendingGmailAccountId;
    private String pendingMicrosoftAccountId;
    private AuthorizationService authService;

    private ActivityResultLauncher<IntentSenderRequest> gmailResolutionLauncher;
    private ActivityResultLauncher<Intent> microsoftAuthLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        accountStore = new AccountStore(this);
        db = new MailDatabase(this);
        authService = new AuthorizationService(this);

        gmailResolutionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartIntentSenderForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        try {
                            AuthorizationResult ar = Identity.getAuthorizationClient(this)
                                    .getAuthorizationResultFromIntent(result.getData());
                            handleGmailToken(ar.getAccessToken());
                        } catch (ApiException e) {
                            toast("No se pudo autorizar Gmail");
                        }
                    }
                });

        microsoftAuthLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> handleMicrosoftAuthResult(result.getResultCode(), result.getData()));

        buildShell();
        showDashboard();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
        if (authService != null) authService.dispose();
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(Ui.dp(this, 18), Ui.dp(this, 16), Ui.dp(this, 18), Ui.dp(this, 12));
        title = Ui.text(this, "Correo Claro", 24, Ui.TEXT, true);
        subtitle = Ui.text(this, "Tus cuentas en un solo lugar", 13, Ui.MUTED, false);
        header.addView(title);
        header.addView(subtitle);
        root.addView(header);

        HorizontalScrollView navScroll = new HorizontalScrollView(this);
        navScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(Ui.dp(this, 12), Ui.dp(this, 2), Ui.dp(this, 12), Ui.dp(this, 10));

        addNav(nav, "Hoy", this::showDashboard);
        addNav(nav, "Pendientes", () -> showInbox(true, null));
        addNav(nav, "Correos", () -> showInbox(false, null));
        addNav(nav, "Cuentas", this::showAccounts);
        addNav(nav, "Configuración", this::showSettings);
        navScroll.addView(nav);
        root.addView(navScroll);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        setContentView(root);
    }

    private void addNav(LinearLayout nav, String label, Runnable action) {
        Button b = Ui.button(this, label, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, Ui.dp(this, 42));
        lp.setMargins(0, 0, Ui.dp(this, 8), 0);
        nav.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }

    private void prepare(String t, String s) {
        title.setText(t);
        subtitle.setText(s);
        content.removeAllViews();
        content.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 24));
    }

    private void showDashboard() {
        prepare("Hoy", "Lo importante de todas tus cuentas");

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        addMetric(row, "Correos", db.countAll(), Ui.BLUE);
        addMetric(row, "Pendientes", db.countActionable(), Ui.YELLOW);
        addMetric(row, "No leídos", db.countUnread(), Ui.CYAN);
        content.addView(row);

        TextView h = Ui.text(this, "Clasificación", 18, Ui.TEXT, true);
        LinearLayout.LayoutParams hp = Ui.mp(LinearLayout.LayoutParams.WRAP_CONTENT);
        hp.setMargins(0, Ui.dp(this, 18), 0, Ui.dp(this, 8));
        content.addView(h, hp);

        for (String cat : MailClassifier.CATEGORIES) {
            int count = db.countCategory(cat);
            LinearLayout c = Ui.card(this);
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.HORIZONTAL);
            TextView name = Ui.text(this, cat, 15, Ui.TEXT, true);
            TextView value = Ui.text(this, String.valueOf(count), 15, Ui.CYAN, true);
            r.addView(name, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            r.addView(value);
            c.addView(r);
            c.setOnClickListener(v -> showInbox(false, cat));
            content.addView(c, spaced());
        }

        List<MailAccount> accounts = accountStore.all();
        if (accounts.isEmpty()) {
            LinearLayout empty = Ui.card(this);
            empty.addView(Ui.text(this, "Todavía no has conectado ninguna cuenta.", 16, Ui.TEXT, true));
            TextView d = Ui.text(this,
                    "Agrega Gmail, Hotmail/Outlook o un dominio propio. La versión inicial trabaja en modo de solo lectura.",
                    14, Ui.MUTED, false);
            d.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 12));
            empty.addView(d);
            Button add = Ui.button(this, "Agregar mi primera cuenta", true);
            add.setOnClickListener(v -> showAccounts());
            empty.addView(add);
            content.addView(empty, spacedTop(18));
        } else {
            Button sync = Ui.button(this, "Actualizar todas", true);
            sync.setOnClickListener(v -> syncAll());
            content.addView(sync, spacedTop(18));
        }
    }

    private void addMetric(LinearLayout row, String label, int value, int accent) {
        LinearLayout c = Ui.card(this);
        TextView v = Ui.text(this, String.valueOf(value), 24, accent, true);
        TextView l = Ui.text(this, label, 12, Ui.MUTED, false);
        c.addView(v);
        c.addView(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
        row.addView(c, lp);
    }

    private void showInbox(boolean actionableOnly, String category) {
        String t = actionableOnly ? "Pendientes" : (category == null ? "Correos" : category);
        prepare(t, actionableOnly ? "Mensajes que probablemente necesitan una acción tuya" : "Últimos mensajes sincronizados");

        EditText search = Ui.input(this, "Buscar remitente, asunto o texto...");
        content.addView(search, Ui.mp(Ui.dp(this, 46)));

        Button go = Ui.button(this, "Buscar", false);
        content.addView(go, spaced());

        LinearLayout results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        content.addView(results);

        Runnable render = () -> {
            results.removeAllViews();
            List<MailItem> mails = db.query(null, category, actionableOnly, search.getText().toString(), 100);
            if (mails.isEmpty()) {
                results.addView(Ui.text(this, "No hay resultados todavía.", 15, Ui.MUTED, false), spacedTop(16));
                return;
            }
            DateFormat fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
            for (MailItem m : mails) {
                LinearLayout c = Ui.card(this);
                LinearLayout top = new LinearLayout(this);
                top.setOrientation(LinearLayout.HORIZONTAL);
                TextView cat = Ui.text(this, m.category, 11, m.actionable ? Ui.YELLOW : Ui.CYAN, true);
                TextView date = Ui.text(this, fmt.format(new Date(m.receivedAt)), 11, Ui.MUTED, false);
                top.addView(cat, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                top.addView(date);
                c.addView(top);

                TextView subject = Ui.text(this, m.subject == null || m.subject.isEmpty() ? "(Sin asunto)" : m.subject, 15, Ui.TEXT, true);
                subject.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 4));
                c.addView(subject);

                c.addView(Ui.text(this, m.from == null ? "" : m.from, 13, Ui.MUTED, false));
                if (m.snippet != null && !m.snippet.isEmpty()) {
                    TextView sn = Ui.text(this, m.snippet, 13, Ui.MUTED, false);
                    sn.setMaxLines(2);
                    sn.setPadding(0, Ui.dp(this, 6), 0, 0);
                    c.addView(sn);
                }
                results.addView(c, spaced());
            }
        };

        go.setOnClickListener(v -> render.run());
        render.run();
    }

    private void showAccounts() {
        prepare("Cuentas", "Conecta tus correos. Nada se borra ni se envía.");

        Button gmail = Ui.button(this, "Agregar Gmail", true);
        gmail.setOnClickListener(v -> beginGmailAdd());
        content.addView(gmail, spaced());

        Button ms = Ui.button(this, "Agregar Outlook / Hotmail / Microsoft 365", false);
        ms.setOnClickListener(v -> beginMicrosoftAdd());
        content.addView(ms, spaced());

        Button imap = Ui.button(this, "Agregar dominio propio / IMAP", false);
        imap.setOnClickListener(v -> showImapDialog());
        content.addView(imap, spaced());

        List<MailAccount> list = accountStore.all();
        if (!list.isEmpty()) {
            TextView h = Ui.text(this, "Conectadas", 18, Ui.TEXT, true);
            content.addView(h, spacedTop(18));
        }

        DateFormat fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
        for (MailAccount a : list) {
            LinearLayout c = Ui.card(this);
            c.addView(Ui.text(this, a.email == null || a.email.isEmpty() ? a.displayName : a.email, 16, Ui.TEXT, true));
            String provider = providerName(a.provider);
            c.addView(Ui.text(this, provider, 13, Ui.CYAN, false));
            String last = a.lastSync > 0 ? "Última actualización: " + fmt.format(new Date(a.lastSync)) : "Sin actualizar";
            c.addView(Ui.text(this, last, 12, Ui.MUTED, false));

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            Button sync = Ui.button(this, "Actualizar", false);
            Button del = Ui.button(this, "Quitar", false);
            actions.addView(sync, new LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1));
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, Ui.dp(this, 42), 1);
            dp.setMargins(Ui.dp(this, 8), 0, 0, 0);
            actions.addView(del, dp);
            actions.setPadding(0, Ui.dp(this, 12), 0, 0);
            c.addView(actions);

            sync.setOnClickListener(v -> syncAccount(a));
            del.setOnClickListener(v -> confirmDelete(a));
            content.addView(c, spaced());
        }
    }

    private String providerName(String p) {
        if (MailAccount.GMAIL.equals(p)) return "Gmail";
        if (MailAccount.MICROSOFT.equals(p)) return "Microsoft";
        return "IMAP / dominio propio";
    }

    private void confirmDelete(MailAccount a) {
        new AlertDialog.Builder(this)
                .setTitle("Quitar cuenta")
                .setMessage("Se quitará la conexión y los correos guardados localmente de esta cuenta. No se borrará nada del servidor.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Quitar", (d, w) -> {
                    accountStore.delete(a.id);
                    db.deleteAccount(a.id);
                    showAccounts();
                }).show();
    }

    private void beginGmailAdd() {
        MailAccount a = new MailAccount();
        a.id = UUID.randomUUID().toString();
        a.provider = MailAccount.GMAIL;
        a.displayName = "Gmail";
        pendingGmailAccountId = a.id;
        accountStore.save(a);
        authorizeGmail(a.id);
    }

    private void authorizeGmail(String accountId) {
        pendingGmailAccountId = accountId;
        AuthorizationRequest request = new AuthorizationRequest.Builder()
                .setRequestedScopes(Arrays.asList(
                        new Scope("https://www.googleapis.com/auth/gmail.readonly"),
                        new Scope("openid"),
                        new Scope("email")))
                .build();

        Identity.getAuthorizationClient(this).authorize(request)
                .addOnSuccessListener(result -> {
                    if (result.hasResolution() && result.getPendingIntent() != null) {
                        try {
                            IntentSenderRequest isr = new IntentSenderRequest.Builder(
                                    result.getPendingIntent().getIntentSender()).build();
                            gmailResolutionLauncher.launch(isr);
                        } catch (Exception e) {
                            toast("No se pudo abrir Google");
                        }
                    } else {
                        handleGmailToken(result.getAccessToken());
                    }
                })
                .addOnFailureListener(e -> {
                    toast("Gmail necesita autorización de Google Cloud para esta APK.");
                    showGmailSetupHelp();
                });
    }

    private void handleGmailToken(String accessToken) {
        if (accessToken == null || accessToken.isEmpty()) {
            toast("Google no devolvió un token");
            return;
        }
        String accountId = pendingGmailAccountId;
        executor.execute(() -> {
            try {
                String email = GmailConnector.fetchEmail(accessToken);
                MailAccount a = accountStore.byId(accountId);
                if (a == null) return;
                a.email = email;
                a.displayName = email;
                List<MailItem> mails = GmailConnector.sync(a.id, accessToken);
                db.upsert(mails);
                a.lastSync = System.currentTimeMillis();
                accountStore.save(a);
                runOnUiThread(() -> {
                    toast("Gmail conectado: " + email);
                    showAccounts();
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("No se pudo leer Gmail"));
            }
        });
    }

    private void showGmailSetupHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Preparar Gmail")
                .setMessage("Para que Google confíe en esta APK hay que registrar una vez el paquete com.correoclaro.app y la huella SHA-1 de la firma en Google Cloud, además de habilitar Gmail API. No necesitas poner tu contraseña en la app.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void beginMicrosoftAdd() {
        String clientId = accountStore.secure().get("microsoft_client_id", "");
        if (clientId.isEmpty()) {
            toast("Primero pega el Client ID de Microsoft en Configuración.");
            showSettings();
            return;
        }

        MailAccount a = new MailAccount();
        a.id = UUID.randomUUID().toString();
        a.provider = MailAccount.MICROSOFT;
        a.displayName = "Microsoft";
        accountStore.save(a);
        pendingMicrosoftAccountId = a.id;
        authorizeMicrosoft(a.id, null);
    }

    private void authorizeMicrosoft(String accountId, AuthState existing) {
        String clientId = accountStore.secure().get("microsoft_client_id", "");
        if (clientId.isEmpty()) {
            toast("Falta el Client ID de Microsoft");
            return;
        }
        pendingMicrosoftAccountId = accountId;

        AuthorizationServiceConfiguration config = new AuthorizationServiceConfiguration(
                Uri.parse("https://login.microsoftonline.com/common/oauth2/v2.0/authorize"),
                Uri.parse("https://login.microsoftonline.com/common/oauth2/v2.0/token")
        );

        net.openid.appauth.AuthorizationRequest request =
                new Builder(config, clientId, ResponseTypeValues.CODE,
                        Uri.parse("com.correoclaro.app:/oauth2redirect"))
                        .setScopes("openid", "profile", "offline_access", "User.Read", "Mail.Read")
                        .build();

        Intent intent = authService.getAuthorizationRequestIntent(request);
        microsoftAuthLauncher.launch(intent);
    }

    private void handleMicrosoftAuthResult(int resultCode, Intent data) {
        if (data == null || pendingMicrosoftAccountId == null) return;

        AuthorizationResponse response = AuthorizationResponse.fromIntent(data);
        AuthorizationException ex = AuthorizationException.fromIntent(data);
        if (response == null) {
            toast("Microsoft no autorizó la cuenta");
            return;
        }

        AuthState state = new AuthState(response, ex);
        String accountId = pendingMicrosoftAccountId;

        authService.performTokenRequest(response.createTokenExchangeRequest(),
                (tokenResponse, tokenEx) -> {
                    state.update(tokenResponse, tokenEx);
                    if (tokenResponse == null || tokenResponse.accessToken == null) {
                        runOnUiThread(() -> toast("No se pudo obtener acceso de Microsoft"));
                        return;
                    }
                    accountStore.secure().put("ms_auth_" + accountId, state.jsonSerializeString());
                    finishMicrosoftConnection(accountId, tokenResponse.accessToken);
                });
    }

    private void finishMicrosoftConnection(String accountId, String token) {
        executor.execute(() -> {
            try {
                JSONObject p = MicrosoftConnector.profile(token);
                String email = p.optString("mail");
                if (email.isEmpty()) email = p.optString("userPrincipalName");
                String display = p.optString("displayName");

                MailAccount a = accountStore.byId(accountId);
                if (a == null) return;
                a.email = email;
                a.displayName = display.isEmpty() ? email : display;
                List<MailItem> mails = MicrosoftConnector.sync(a.id, token);
                db.upsert(mails);
                a.lastSync = System.currentTimeMillis();
                accountStore.save(a);

                String finalEmail = email;
                runOnUiThread(() -> {
                    toast("Microsoft conectado: " + finalEmail);
                    showAccounts();
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("No se pudo leer Microsoft"));
            }
        });
    }

    private void showImapDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        form.setPadding(p, p / 2, p, 0);

        EditText email = Ui.input(this, "Correo");
        EditText host = Ui.input(this, "Servidor IMAP, ej. mail.midominio.com");
        EditText port = Ui.input(this, "Puerto (993)");
        port.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText user = Ui.input(this, "Usuario");
        EditText pass = Ui.input(this, "Contraseña / contraseña de aplicación");
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        CheckBox ssl = new CheckBox(this);
        ssl.setText("Usar SSL");
        ssl.setTextColor(Ui.TEXT);
        ssl.setChecked(true);

        form.addView(email, spaced());
        form.addView(host, spaced());
        form.addView(port, spaced());
        form.addView(user, spaced());
        form.addView(pass, spaced());
        form.addView(ssl);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Agregar cuenta IMAP")
                .setView(form)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", null)
                .create();

        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (email.getText().toString().trim().isEmpty() ||
                    host.getText().toString().trim().isEmpty() ||
                    user.getText().toString().trim().isEmpty() ||
                    pass.getText().toString().isEmpty()) {
                toast("Completa los datos requeridos");
                return;
            }
            try {
                MailAccount a = new MailAccount();
                a.id = UUID.randomUUID().toString();
                a.provider = MailAccount.IMAP;
                a.email = email.getText().toString().trim();
                a.displayName = a.email;

                JSONObject cfg = new JSONObject();
                cfg.put("host", host.getText().toString().trim());
                cfg.put("port", parseInt(port.getText().toString(), ssl.isChecked() ? 993 : 143));
                cfg.put("ssl", ssl.isChecked());
                cfg.put("username", user.getText().toString().trim());
                a.configJson = cfg.toString();
                accountStore.save(a);
                accountStore.secure().put("imap_pass_" + a.id, pass.getText().toString());
                dialog.dismiss();
                syncAccount(a);
            } catch (Exception e) {
                toast("No se pudo guardar la cuenta");
            }
        }));
        dialog.show();
    }

    private void showSettings() {
        prepare("Configuración", "Conexiones y privacidad");

        LinearLayout ms = Ui.card(this);
        ms.addView(Ui.text(this, "Microsoft", 17, Ui.TEXT, true));
        TextView desc = Ui.text(this,
                "Para Outlook/Hotmail necesitas registrar esta app una vez en Microsoft Entra y pegar aquí su Client ID.",
                13, Ui.MUTED, false);
        desc.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
        ms.addView(desc);

        EditText clientId = Ui.input(this, "Microsoft Client ID");
        clientId.setText(accountStore.secure().get("microsoft_client_id", ""));
        ms.addView(clientId);

        TextView redirect = Ui.text(this, "Redirect URI: com.correoclaro.app:/oauth2redirect", 12, Ui.CYAN, false);
        redirect.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
        ms.addView(redirect);

        Button save = Ui.button(this, "Guardar Client ID", true);
        save.setOnClickListener(v -> {
            accountStore.secure().put("microsoft_client_id", clientId.getText().toString().trim());
            toast("Configuración guardada");
        });
        ms.addView(save);
        content.addView(ms, spaced());

        LinearLayout privacy = Ui.card(this);
        privacy.addView(Ui.text(this, "Privacidad", 17, Ui.TEXT, true));
        TextView p = Ui.text(this,
                "Esta v1 trabaja en modo solo lectura. Los mensajes sincronizados y la clasificación se guardan únicamente en este teléfono. Las contraseñas IMAP y tokens se protegen con Android Keystore.",
                13, Ui.MUTED, false);
        p.setPadding(0, Ui.dp(this, 6), 0, 0);
        privacy.addView(p);
        content.addView(privacy, spaced());

        Button appInfo = Ui.button(this, "Abrir información de la app", false);
        appInfo.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });
        content.addView(appInfo, spaced());
    }

    private void syncAll() {
        List<MailAccount> list = accountStore.all();
        if (list.isEmpty()) {
            showAccounts();
            return;
        }
        toast("Actualizando cuentas...");
        for (MailAccount a : list) syncAccount(a);
    }

    private void syncAccount(MailAccount a) {
        if (MailAccount.GMAIL.equals(a.provider)) {
            authorizeGmail(a.id);
            return;
        }
        if (MailAccount.MICROSOFT.equals(a.provider)) {
            String raw = accountStore.secure().get("ms_auth_" + a.id, "");
            if (raw.isEmpty()) {
                pendingMicrosoftAccountId = a.id;
                authorizeMicrosoft(a.id, null);
                return;
            }
            try {
                AuthState state = AuthState.jsonDeserialize(raw);
                state.performActionWithFreshTokens(authService, (accessToken, idToken, ex) -> {
                    if (ex != null || accessToken == null) {
                        runOnUiThread(() -> {
                            toast("Microsoft necesita volver a iniciar sesión");
                            pendingMicrosoftAccountId = a.id;
                            authorizeMicrosoft(a.id, state);
                        });
                        return;
                    }
                    accountStore.secure().put("ms_auth_" + a.id, state.jsonSerializeString());
                    executor.execute(() -> {
                        try {
                            List<MailItem> mails = MicrosoftConnector.sync(a.id, accessToken);
                            db.upsert(mails);
                            a.lastSync = System.currentTimeMillis();
                            accountStore.save(a);
                            runOnUiThread(() -> {
                                toast("Actualizado: " + a.email);
                                showAccounts();
                            });
                        } catch (Exception e) {
                            runOnUiThread(() -> toast("Error al actualizar Microsoft"));
                        }
                    });
                });
            } catch (Exception e) {
                pendingMicrosoftAccountId = a.id;
                authorizeMicrosoft(a.id, null);
            }
            return;
        }

        executor.execute(() -> {
            try {
                JSONObject cfg = new JSONObject(a.configJson);
                String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                List<MailItem> mails = ImapConnector.sync(a.id, cfg, pass);
                db.upsert(mails);
                a.lastSync = System.currentTimeMillis();
                accountStore.save(a);
                runOnUiThread(() -> {
                    toast("Actualizado: " + a.email);
                    showAccounts();
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("No se pudo conectar por IMAP. Revisa servidor, puerto y contraseña."));
            }
        });
    }

    private int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return fallback; }
    }

    private LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams p = Ui.mp(LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        return p;
    }

    private LinearLayout.LayoutParams spacedTop(int top) {
        LinearLayout.LayoutParams p = Ui.mp(LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, Ui.dp(this, top), 0, Ui.dp(this, 6));
        return p;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
