package com.correoclaro.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.correoclaro.app.data.AccountStore;
import com.correoclaro.app.data.FolderStore;
import com.correoclaro.app.data.MailDatabase;
import com.correoclaro.app.data.RuleStore;
import com.correoclaro.app.model.MailAccount;
import com.correoclaro.app.model.MailFolder;
import com.correoclaro.app.model.MailItem;
import com.correoclaro.app.model.MailRule;
import com.correoclaro.app.provider.GmailConnector;
import com.correoclaro.app.provider.ImapConnector;
import com.correoclaro.app.provider.MicrosoftConnector;
import com.correoclaro.app.ui.Ui;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;

import net.openid.appauth.AuthState;
import net.openid.appauth.AuthorizationException;
import net.openid.appauth.AuthorizationRequest.Builder;
import net.openid.appauth.AuthorizationResponse;
import net.openid.appauth.AuthorizationService;
import net.openid.appauth.AuthorizationServiceConfiguration;
import net.openid.appauth.ResponseTypeValues;

import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final Set<String> selected = new HashSet<>();
    private final List<MailItem> currentVisible = new ArrayList<>();

    private AccountStore accountStore;
    private FolderStore folderStore;
    private MailDatabase db;
    private RuleStore ruleStore;

    private LinearLayout content;
    private LinearLayout header;
    private LinearLayout bottomNav;
    private TextView title;
    private TextView subtitle;
    private TextView statusText;
    private ProgressBar statusProgress;

    private long lastBackPress = 0;
    private Runnable contextualBack;
    private long screenGeneration = 0;

    private String pendingGmailAccountId;
    private String pendingMicrosoftAccountId;
    private AuthorizationService authService;
    private ActivityResultLauncher<IntentSenderRequest> gmailResolutionLauncher;
    private ActivityResultLauncher<Intent> microsoftAuthLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        accountStore = new AccountStore(this);
        folderStore = new FolderStore(accountStore.secure());
        db = new MailDatabase(this);
        ruleStore = new RuleStore(accountStore.secure());
        authService = new AuthorizationService(this);

        gmailResolutionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartIntentSenderForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        try {
                            AuthorizationResult ar = Identity.getAuthorizationClient(this)
                                    .getAuthorizationResultFromIntent(result.getData());
                            handleGmailToken(ar.getAccessToken());
                        } catch (ApiException e) {
                            setStatus("Gmail no autorizó el acceso", false, true);
                        }
                    }
                });

        microsoftAuthLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> handleMicrosoftAuthResult(result.getResultCode(), result.getData()));

        buildShell();
        showDashboard();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
        if (authService != null) authService.dispose();
    }

    @Override
    public void onBackPressed() {
        if (!selected.isEmpty()) {
            selected.clear();
            toast("Selección cancelada");
            return;
        }
        if (contextualBack != null) {
            Runnable back = contextualBack;
            contextualBack = null;
            back.run();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastBackPress <= 1800) {
            finish();
        } else {
            lastBackPress = now;
            Toast.makeText(this, "Presiona atrás otra vez para salir", Toast.LENGTH_SHORT).show();
        }
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);

        header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 8));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        title = Ui.text(this, "Correo Fácil", 23, Ui.TEXT, true);
        subtitle = Ui.text(this, "Correo simple, bajo tu control", 12, Ui.MUTED, false);
        names.addView(title);
        names.addView(subtitle);
        top.addView(names, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        Button compose = Ui.compactButton(this, "Nuevo", true);
        compose.setOnClickListener(v -> showCompose(null));
        top.addView(compose, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, Ui.dp(this, 38)));

        Button settings = Ui.compactButton(this, "Ajustes", false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, Ui.dp(this, 38));
        sp.setMargins(Ui.dp(this, 8), 0, 0, 0);
        top.addView(settings, sp);
        settings.setOnClickListener(v -> showSettings());
        header.addView(top);

        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.HORIZONTAL);
        status.setGravity(Gravity.CENTER_VERTICAL);
        status.setPadding(0, Ui.dp(this, 7), 0, 0);
        statusProgress = new ProgressBar(this);
        statusProgress.setIndeterminate(true);
        statusProgress.setVisibility(View.GONE);
        status.addView(statusProgress, new LinearLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18)));
        statusText = Ui.text(this, "Listo", 11, Ui.GREEN, false);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        stp.setMargins(Ui.dp(this, 7), 0, 0, 0);
        status.addView(statusText, stp);
        header.addView(status);
        root.addView(header);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        bottomNav = new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setPadding(Ui.dp(this, 8), Ui.dp(this, 5), Ui.dp(this, 8), Ui.dp(this, 5));
        bottomNav.setBackgroundColor(Ui.PANEL);
        addBottomNav("Hoy", this::showDashboard);
        addBottomNav("Correo", this::showAllMail);
        addBottomNav("Carpetas", this::showFolders);
        addBottomNav("Reglas", this::showRules);
        addBottomNav("Cuentas", this::showAccounts);
        root.addView(bottomNav);

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            header.setPadding(Ui.dp(this, 16), bars.top + Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8));
            bottomNav.setPadding(Ui.dp(this, 8), Ui.dp(this, 5), Ui.dp(this, 8), bars.bottom + Ui.dp(this, 5));
            return insets;
        });

        setContentView(root);
    }

    private void addBottomNav(String label, Runnable action) {
        Button b = Ui.navButton(this, label);
        bottomNav.addView(b, new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1));
        b.setOnClickListener(v -> action.run());
    }

    private void prepare(String t, String s, Runnable back) {
        screenGeneration++;
        contextualBack = back;
        selected.clear();
        currentVisible.clear();
        title.setText(t);
        subtitle.setText(s);
        content.removeAllViews();
        content.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 24));
    }

    private void setStatus(String text, boolean busy, boolean error) {
        runOnUiThread(() -> {
            statusProgress.setVisibility(busy ? View.VISIBLE : View.GONE);
            statusText.setText(text);
            statusText.setTextColor(error ? Ui.RED : (busy ? Ui.CYAN : Ui.GREEN));
        });
    }

    private void showDashboard() {
        prepare("Hoy", "Lo importante de todas tus cuentas", null);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        addMetric(metrics, "No leídos", db.countUnread(), Ui.CYAN);
        addMetric(metrics, "Pendientes", db.countPending(), Ui.YELLOW);
        addMetric(metrics, "Cuentas", accountStore.all().size(), Ui.BLUE);
        content.addView(metrics);

        LinearLayout shortcuts = new LinearLayout(this);
        shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        Button pendingView = Ui.compactButton(this, "Ver pendientes", false);
        Button allView = Ui.compactButton(this, "Ver correos", false);
        shortcuts.addView(pendingView, new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1));
        LinearLayout.LayoutParams avp = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
        avp.setMargins(Ui.dp(this, 8), 0, 0, 0);
        shortcuts.addView(allView, avp);
        pendingView.setOnClickListener(v -> showPending());
        allView.setOnClickListener(v -> showAllMail());
        content.addView(shortcuts, spacedTop(10));

        Button update = Ui.button(this, "Actualizar todas las cuentas", true);
        update.setOnClickListener(v -> syncAll());
        content.addView(update, spacedTop(14));

        TextView h = Ui.text(this, "Carpetas", 18, Ui.TEXT, true);
        content.addView(h, spacedTop(18));

        int shown = 0;
        for (MailAccount a : accountStore.all()) {
            if (!MailAccount.IMAP.equals(a.provider)) continue;
            for (MailFolder f : folderStore.all(a.id)) {
                if (shown >= 8) break;
                LinearLayout card = Ui.card(this);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout left = new LinearLayout(this);
                left.setOrientation(LinearLayout.VERTICAL);
                left.addView(Ui.text(this, f.displayName, 15, Ui.TEXT, true));
                left.addView(Ui.text(this, a.email, 11, Ui.MUTED, false));
                row.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                int unread = db.countFolderUnread(a.id, f.name);
                row.addView(Ui.badge(this, unread + " no leídos", unread > 0 ? Ui.CYAN : Ui.MUTED));
                card.addView(row);
                card.setOnClickListener(v -> syncFolderAndOpen(a, f));
                content.addView(card, spaced());
                shown++;
            }
            if (shown >= 8) break;
        }

        if (accountStore.all().isEmpty()) {
            LinearLayout empty = Ui.card(this);
            empty.addView(Ui.text(this, "Conecta tu primer correo", 16, Ui.TEXT, true));
            TextView d = Ui.text(this, "Para Gmail con clave de aplicación sólo necesitas tu correo y la clave de 16 caracteres.", 13, Ui.MUTED, false);
            d.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
            empty.addView(d);
            Button add = Ui.button(this, "Agregar cuenta", true);
            add.setOnClickListener(v -> showAccounts());
            empty.addView(add);
            content.addView(empty, spacedTop(16));
        } else if (shown == 0) {
            content.addView(Ui.text(this, "Actualiza una cuenta IMAP/SMTP para cargar sus carpetas.", 13, Ui.MUTED, false), spaced());
        }
    }

    private void addMetric(LinearLayout row, String label, int value, int accent) {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, String.valueOf(value), 23, accent, true));
        c.addView(Ui.text(this, label, 11, Ui.MUTED, false));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
        lp.setMargins(Ui.dp(this, 3), 0, Ui.dp(this, 3), 0);
        row.addView(c, lp);
    }

    private void showAllMail() {
        showMailList(null, null, false, "Correos", "Todos los mensajes sincronizados", null);
    }

    private void showPending() {
        showMailList(null, null, true, "Pendientes", "Marcados por ti para dar seguimiento", null);
    }

    private void showMailList(String accountId, String folder, boolean pendingOnly,
                              String t, String s, Runnable backAction) {
        prepare(t, s, backAction);

        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        Button pending = Ui.compactButton(this, "Pendientes", false);
        Button unread = Ui.compactButton(this, "No leídos", false);
        quick.addView(pending, new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1));
        LinearLayout.LayoutParams up = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
        up.setMargins(Ui.dp(this, 8), 0, 0, 0);
        quick.addView(unread, up);
        content.addView(quick, spaced());
        pending.setOnClickListener(v -> showPending());

        EditText search = Ui.input(this, "Buscar remitente o asunto...");
        content.addView(search, spaced());
        content.addView(Ui.text(this,
                "Mantén presionado un correo para seleccionar. Cargamos por bloques para mantener la app rápida.",
                11, Ui.MUTED, false), spaced());

        LinearLayout selectionHost = new LinearLayout(this);
        selectionHost.setOrientation(LinearLayout.VERTICAL);
        content.addView(selectionHost);

        LinearLayout results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        content.addView(results);

        final boolean[] unreadOnly = {false};
        final int[] pageSize = {25};
        Runnable[] render = new Runnable[1];

        render[0] = () -> {
            results.removeAllViews();
            selectionHost.removeAllViews();
            currentVisible.clear();

            List<MailItem> fetched = db.query(
                    accountId, folder, pendingOnly, unreadOnly[0],
                    search.getText().toString(), pageSize[0] + 1);

            boolean hasMore = fetched.size() > pageSize[0];
            int visibleCount = Math.min(pageSize[0], fetched.size());

            for (int i = 0; i < visibleCount; i++) {
                currentVisible.add(fetched.get(i));
            }

            if (!selected.isEmpty()) buildSelectionBar(selectionHost, render[0]);

            if (currentVisible.isEmpty()) {
                results.addView(Ui.text(this, "No hay mensajes en esta vista.", 14, Ui.MUTED, false),
                        spacedTop(18));
                return;
            }

            DateFormat fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);

            for (MailItem mail : currentVisible) {
                boolean isSelected = selected.contains(key(mail));
                LinearLayout card = isSelected ? Ui.selectedCard(this) : Ui.card(this);

                LinearLayout meta = new LinearLayout(this);
                meta.setOrientation(LinearLayout.HORIZONTAL);
                MailAccount a = accountStore.byId(mail.accountId);
                String accountLabel = a == null ? "" : a.email;

                TextView left = Ui.text(this, (isSelected ? "✓  " : "") + accountLabel,
                        11, isSelected ? Ui.CYAN : Ui.MUTED, isSelected);
                meta.addView(left, new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

                meta.addView(Ui.text(this, fmt.format(new Date(mail.receivedAt)),
                        11, Ui.MUTED, false));
                card.addView(meta);

                String subjectText = (mail.unread ? "●  " : "") +
                        ((mail.subject == null || mail.subject.isEmpty())
                                ? "(Sin asunto)" : mail.subject);

                TextView subject = Ui.text(this, subjectText, 15, Ui.TEXT, mail.unread);
                subject.setMaxLines(2);
                subject.setPadding(0, Ui.dp(this, 7), 0, Ui.dp(this, 3));
                card.addView(subject);

                TextView sender = Ui.text(this, mail.from == null ? "" : mail.from,
                        12, Ui.MUTED, false);
                sender.setMaxLines(1);
                card.addView(sender);

                LinearLayout badges = new LinearLayout(this);
                badges.setOrientation(LinearLayout.HORIZONTAL);
                badges.setPadding(0, Ui.dp(this, 7), 0, 0);

                String folderLabel = mail.folder == null
                        ? "INBOX" : displayFolder(mail.accountId, mail.folder);
                badges.addView(Ui.badge(this, folderLabel, Ui.CYAN));

                if (mail.actionable) {
                    LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT);
                    bp.setMargins(Ui.dp(this, 7), 0, 0, 0);
                    badges.addView(Ui.badge(this, "Pendiente", Ui.YELLOW), bp);
                }

                card.addView(badges);

                card.setOnLongClickListener(v -> {
                    toggleSelected(mail);
                    render[0].run();
                    return true;
                });

                card.setOnClickListener(v -> {
                    if (!selected.isEmpty()) {
                        toggleSelected(mail);
                        render[0].run();
                    } else {
                        Runnable back = () -> showMailList(
                                accountId, folder, pendingOnly, t, s, backAction);
                        showMessage(mail, back);
                    }
                });

                results.addView(card, spaced());
            }

            if (hasMore) {
                Button more = Ui.button(this, "Cargar 25 más", false);
                more.setOnClickListener(v -> {
                    pageSize[0] = Math.min(pageSize[0] + 25, 200);
                    setStatus("Mostrando " + pageSize[0] + " correos", false, false);
                    render[0].run();
                });
                results.addView(more, spacedTop(6));
            }

            TextView count = Ui.text(this,
                    currentVisible.size() + (hasMore ? "+ correos" : " correos"),
                    11, Ui.MUTED, false);
            count.setGravity(Gravity.CENTER_HORIZONTAL);
            results.addView(count, spacedTop(8));
        };

        search.setOnEditorActionListener((v, actionId, event) -> {
            pageSize[0] = 25;
            render[0].run();
            return false;
        });

        unread.setOnClickListener(v -> {
            unreadOnly[0] = !unreadOnly[0];
            unread.setText(unreadOnly[0] ? "Todos" : "No leídos");
            pageSize[0] = 25;
            render[0].run();
        });

        render[0].run();
    }

    private void buildSelectionBar(LinearLayout host, Runnable render) {
        LinearLayout bar = Ui.card(this);
        bar.addView(Ui.text(this, selected.size() + " seleccionados", 14, Ui.CYAN, true));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button read = Ui.compactButton(this, "Leído", false);
        Button pending = Ui.compactButton(this, "Pendiente", false);
        Button move = Ui.compactButton(this, "Mover", false);
        row1.addView(read, new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
        rp.setMargins(Ui.dp(this, 6), 0, 0, 0);
        row1.addView(pending, rp);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
        mp.setMargins(Ui.dp(this, 6), 0, 0, 0);
        row1.addView(move, mp);
        row1.setPadding(0, Ui.dp(this, 9), 0, 0);
        bar.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button unread = Ui.compactButton(this, "No leído", false);
        Button trash = Ui.compactButton(this, "Papelera", false);
        Button cancel = Ui.compactButton(this, "Cancelar", false);
        row2.addView(unread, new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1));
        LinearLayout.LayoutParams t = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
        t.setMargins(Ui.dp(this, 6), 0, 0, 0);
        row2.addView(trash, t);
        LinearLayout.LayoutParams c = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
        c.setMargins(Ui.dp(this, 6), 0, 0, 0);
        row2.addView(cancel, c);
        row2.setPadding(0, Ui.dp(this, 6), 0, 0);
        bar.addView(row2);

        read.setOnClickListener(v -> setSelectedSeen(true, render));
        unread.setOnClickListener(v -> setSelectedSeen(false, render));
        pending.setOnClickListener(v -> toggleSelectedPending(render));
        move.setOnClickListener(v -> showMoveSelectedDialog(render));
        trash.setOnClickListener(v -> confirmTrashSelected(render));
        cancel.setOnClickListener(v -> { selected.clear(); render.run(); });
        host.addView(bar, spaced());
    }

    private void toggleSelected(MailItem m) {
        String k = key(m);
        if (selected.contains(k)) selected.remove(k); else selected.add(k);
    }

    private String key(MailItem m) { return m.accountId + "|" + m.remoteId; }

    private List<MailItem> selectedItems() {
        List<MailItem> out = new ArrayList<>();
        for (MailItem m : currentVisible) if (selected.contains(key(m))) out.add(m);
        return out;
    }

    private void toggleSelectedPending(Runnable render) {
        List<MailItem> items = selectedItems();
        boolean makePending = false;
        for (MailItem m : items) if (!m.actionable) { makePending = true; break; }
        for (MailItem m : items) {
            db.setPending(m.accountId, m.remoteId, makePending);
            m.actionable = makePending;
        }
        setStatus(makePending ? "Marcados como pendientes" : "Pendiente quitado", false, false);
        selected.clear();
        render.run();
    }

    private void setSelectedSeen(boolean seen, Runnable render) {
        List<MailItem> items = selectedItems();
        if (items.isEmpty()) return;
        executor.execute(() -> {
            try {
                Map<String, List<MailItem>> groups = groupByAccountFolder(items);
                for (List<MailItem> group : groups.values()) {
                    MailItem first = group.get(0);
                    MailAccount a = accountStore.byId(first.accountId);
                    if (a == null || !MailAccount.IMAP.equals(a.provider)) continue;
                    JSONObject cfg = new JSONObject(a.configJson);
                    String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                    ImapConnector.setSeen(cfg, pass, first.folder, ids(group), seen);
                    for (MailItem m : group) db.setUnread(m.accountId, m.remoteId, !seen);
                }
                runOnUiThread(() -> {
                    selected.clear();
                    setStatus(seen ? "Marcados como leídos" : "Marcados como no leídos", false, false);
                    render.run();
                });
            } catch (Exception e) {
                setStatus("No pude cambiar el estado: " + shortError(e), false, true);
            }
        });
    }

    private void showMoveSelectedDialog(Runnable render) {
        List<MailItem> items = selectedItems();
        if (items.isEmpty()) return;
        String accountId = items.get(0).accountId;
        for (MailItem m : items) if (!accountId.equals(m.accountId)) {
            toast("Para mover, selecciona correos de una sola cuenta.");
            return;
        }
        MailAccount a = accountStore.byId(accountId);
        if (a == null || !MailAccount.IMAP.equals(a.provider)) {
            toast("Mover carpetas está disponible en cuentas IMAP/SMTP.");
            return;
        }
        List<MailFolder> folders = folderStore.all(accountId);
        List<String> labels = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (MailFolder f : folders) {
            labels.add(f.displayName);
            names.add(f.name);
        }
        if (names.isEmpty()) {
            toast("Primero actualiza las carpetas de la cuenta.");
            return;
        }
        Spinner spin = new Spinner(this);
        spin.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        new AlertDialog.Builder(this)
                .setTitle("Mover " + items.size() + " correos")
                .setView(spin)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Mover", (d, w) -> moveSelectedTo(a, items, names.get(spin.getSelectedItemPosition()), render))
                .show();
    }

    private void moveSelectedTo(MailAccount a, List<MailItem> items, String destination, Runnable render) {
        setStatus("Moviendo " + items.size() + " correos...", true, false);
        executor.execute(() -> {
            try {
                JSONObject cfg = new JSONObject(a.configJson);
                String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                Map<String, List<String>> bySource = new LinkedHashMap<>();
                for (MailItem m : items) bySource.computeIfAbsent(m.folder, k -> new ArrayList<>()).add(m.remoteId);
                for (Map.Entry<String, List<String>> e : bySource.entrySet()) {
                    if (!destination.equals(e.getKey())) ImapConnector.moveMessages(cfg, pass, e.getKey(), e.getValue(), destination);
                }
                for (MailItem m : items) db.setFolder(m.accountId, m.remoteId, destination);
                runOnUiThread(() -> {
                    selected.clear();
                    setStatus("Correos movidos a " + displayFolder(a.id, destination), false, false);
                    render.run();
                });
            } catch (Exception e) {
                setStatus("No pude mover los correos: " + shortError(e), false, true);
            }
        });
    }

    private void confirmTrashSelected(Runnable render) {
        List<MailItem> items = selectedItems();
        if (items.isEmpty()) return;
        new AlertDialog.Builder(this)
                .setTitle("Mover a Papelera")
                .setMessage("Se moverán " + items.size() + " correos en el servidor.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Mover", (d, w) -> trashSelected(items, render))
                .show();
    }

    private void trashSelected(List<MailItem> items, Runnable render) {
        setStatus("Moviendo a Papelera...", true, false);
        executor.execute(() -> {
            try {
                Map<String, List<MailItem>> groups = groupByAccountFolder(items);
                for (List<MailItem> group : groups.values()) {
                    MailItem first = group.get(0);
                    MailAccount a = accountStore.byId(first.accountId);
                    if (a == null || !MailAccount.IMAP.equals(a.provider))
                        throw new IllegalStateException("La Papelera masiva requiere IMAP/SMTP");
                    JSONObject cfg = new JSONObject(a.configJson);
                    String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                    ImapConnector.moveToTrash(cfg, pass, first.folder, ids(group));
                    for (MailItem m : group) db.deleteMail(m.accountId, m.remoteId);
                }
                runOnUiThread(() -> {
                    selected.clear();
                    setStatus("Correos movidos a Papelera", false, false);
                    render.run();
                });
            } catch (Exception e) {
                setStatus("No pude mover a Papelera: " + shortError(e), false, true);
            }
        });
    }

    private Map<String, List<MailItem>> groupByAccountFolder(List<MailItem> items) {
        Map<String, List<MailItem>> groups = new LinkedHashMap<>();
        for (MailItem m : items) groups.computeIfAbsent(m.accountId + "\n" + m.folder, k -> new ArrayList<>()).add(m);
        return groups;
    }

    private List<String> ids(List<MailItem> items) {
        List<String> out = new ArrayList<>();
        for (MailItem m : items) out.add(m.remoteId);
        return out;
    }

    private void showMessage(MailItem mail, Runnable back) {
        prepare("Correo", mail.subject == null || mail.subject.isEmpty() ? "(Sin asunto)" : mail.subject, back);
        MailAccount a = accountStore.byId(mail.accountId);

        LinearLayout card = Ui.card(this);
        card.addView(Ui.text(this, mail.from == null ? "" : mail.from, 14, Ui.TEXT, true));
        if (a != null) card.addView(Ui.text(this, "Cuenta: " + a.email, 11, Ui.MUTED, false));
        card.addView(Ui.text(this, "Carpeta: " + displayFolder(mail.accountId, mail.folder), 11, Ui.MUTED, false));
        content.addView(card, spaced());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button reply = Ui.compactButton(this, "Responder", true);
        Button pending = Ui.compactButton(this, mail.actionable ? "Quitar pendiente" : "Pendiente", false);
        Button rule = Ui.compactButton(this, "Crear regla", false);
        actions.addView(reply, new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1);
        ap.setMargins(Ui.dp(this, 6), 0, 0, 0);
        actions.addView(pending, ap);
        LinearLayout.LayoutParams ar = new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1);
        ar.setMargins(Ui.dp(this, 6), 0, 0, 0);
        actions.addView(rule, ar);
        content.addView(actions, spaced());

        Button trash = Ui.button(this, "Mover a Papelera", false);
        content.addView(trash, spaced());

        TextView body = Ui.text(this, "Cargando contenido...", 14, Ui.MUTED, false);
        body.setTextIsSelectable(true);
        LinearLayout bodyCard = Ui.card(this);
        bodyCard.addView(body);
        content.addView(bodyCard, spacedTop(12));

        reply.setOnClickListener(v -> showCompose(mail));
        pending.setOnClickListener(v -> {
            boolean value = !mail.actionable;
            db.setPending(mail.accountId, mail.remoteId, value);
            mail.actionable = value;
            setStatus(value ? "Marcado como pendiente" : "Pendiente quitado", false, false);
            showMessage(mail, back);
        });
        rule.setOnClickListener(v -> showRuleDialog(mail));
        trash.setOnClickListener(v -> confirmSingleTrash(mail, back));

        if (a != null && MailAccount.IMAP.equals(a.provider)) {
            final long generation = screenGeneration;
            setStatus("Cargando contenido del correo...", true, false);

            executor.execute(() -> {
                try {
                    JSONObject cfg = new JSONObject(a.configJson);
                    String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                    String text = ImapConnector.fetchBody(cfg, pass, mail.folder, mail.remoteId);

                    ImapConnector.setSeen(cfg, pass, mail.folder,
                            Arrays.asList(mail.remoteId), true);
                    db.setUnread(mail.accountId, mail.remoteId, false);
                    mail.unread = false;

                    final String finalText = text;
                    runOnUiThread(() -> {
                        if (generation != screenGeneration || isFinishing() || isDestroyed()) return;
                        body.setText(finalText);
                        body.setTextColor(Ui.TEXT);
                        setStatus("Contenido cargado", false, false);
                    });

                } catch (Exception e) {
                    final String errorText = shortError(e);
                    runOnUiThread(() -> {
                        if (generation != screenGeneration || isFinishing() || isDestroyed()) return;
                        body.setText("No pude descargar el contenido.\n\n" + errorText);
                        setStatus("Error al abrir el correo", false, true);
                    });
                }
            });

        } else {
            body.setText(mail.snippet == null || mail.snippet.isEmpty() ? "Vista previa no disponible." : mail.snippet);
        }
    }

    private void confirmSingleTrash(MailItem mail, Runnable back) {
        new AlertDialog.Builder(this)
                .setTitle("Mover a Papelera")
                .setMessage("El correo se moverá en el servidor.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Mover", (d, w) -> {
                    List<MailItem> one = new ArrayList<>();
                    one.add(mail);
                    trashSelected(one, back);
                }).show();
    }

    private void showFolders() {
        prepare("Carpetas", "Sincronizadas con cada cuenta", null);
        List<MailAccount> accounts = accountStore.all();
        if (accounts.isEmpty()) {
            content.addView(Ui.text(this, "Agrega una cuenta para ver sus carpetas.", 14, Ui.MUTED, false), spacedTop(16));
            return;
        }

        for (MailAccount a : accounts) {
            LinearLayout accountCard = Ui.card(this);
            accountCard.addView(Ui.text(this, a.email == null || a.email.isEmpty() ? a.displayName : a.email, 16, Ui.TEXT, true));
            accountCard.addView(Ui.text(this, providerName(a), 11, Ui.CYAN, false));

            if (MailAccount.IMAP.equals(a.provider)) {
                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.HORIZONTAL);
                Button refresh = Ui.compactButton(this, "Actualizar carpetas", false);
                Button create = Ui.compactButton(this, "Nueva carpeta", true);
                actions.addView(refresh, new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1));
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1);
                cp.setMargins(Ui.dp(this, 7), 0, 0, 0);
                actions.addView(create, cp);
                actions.setPadding(0, Ui.dp(this, 10), 0, 0);
                accountCard.addView(actions);
                refresh.setOnClickListener(v -> refreshFolders(a, true));
                create.setOnClickListener(v -> createFolderDialog(a));
            } else {
                TextView note = Ui.text(this, "Carpetas bidireccionales: conecta esta cuenta por IMAP/SMTP.", 12, Ui.MUTED, false);
                note.setPadding(0, Ui.dp(this, 8), 0, 0);
                accountCard.addView(note);
            }
            content.addView(accountCard, spacedTop(10));

            if (!MailAccount.IMAP.equals(a.provider)) continue;
            List<MailFolder> folders = folderStore.all(a.id);
            if (folders.isEmpty()) {
                content.addView(Ui.text(this, "Sin carpetas cargadas todavía.", 12, Ui.MUTED, false), spaced());
                continue;
            }
            for (MailFolder f : folders) {
                LinearLayout folderCard = Ui.card(this);
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.addView(Ui.text(this, f.displayName, 14, Ui.TEXT, true),
                        new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                int unread = db.countFolderUnread(a.id, f.name);
                row.addView(Ui.badge(this, String.valueOf(unread), unread > 0 ? Ui.CYAN : Ui.MUTED));
                folderCard.addView(row);
                folderCard.setOnClickListener(v -> syncFolderAndOpen(a, f));
                if (!f.isProtected()) {
                    folderCard.setOnLongClickListener(v -> {
                        manageFolderDialog(a, f);
                        return true;
                    });
                }
                content.addView(folderCard, spaced());
            }
        }
    }

    private void refreshFolders(MailAccount a, boolean returnToFolders) {
        setStatus("Leyendo carpetas de " + a.email + "...", true, false);
        executor.execute(() -> {
            try {
                JSONObject cfg = new JSONObject(a.configJson);
                String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                List<MailFolder> folders = ImapConnector.listFolders(cfg, pass);
                folderStore.save(a.id, folders);
                runOnUiThread(() -> {
                    setStatus("Carpetas actualizadas: " + folders.size(), false, false);
                    if (returnToFolders) showFolders();
                });
            } catch (Exception e) {
                setStatus("No pude leer carpetas: " + shortError(e), false, true);
            }
        });
    }

    private void syncFolderAndOpen(MailAccount a, MailFolder folder) {
        setStatus("Sincronizando " + folder.displayName + "...", true, false);
        executor.execute(() -> {
            try {
                JSONObject cfg = new JSONObject(a.configJson);
                String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                List<MailItem> mails = ImapConnector.syncFolder(a.id, cfg, pass, folder.name, 100);
                db.deleteFolderCache(a.id, folder.name);
                db.upsert(mails);
                runOnUiThread(() -> {
                    setStatus(folder.displayName + " · " + mails.size() + " mensajes", false, false);
                    showMailList(a.id, folder.name, false, folder.displayName, a.email, this::showFolders);
                });
            } catch (Exception e) {
                setStatus("No pude sincronizar la carpeta: " + shortError(e), false, true);
            }
        });
    }

    private void createFolderDialog(MailAccount a) {
        EditText name = Ui.input(this, "Nombre de la carpeta");
        new AlertDialog.Builder(this)
                .setTitle("Nueva carpeta en " + a.email)
                .setView(name)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Crear", (d, w) -> {
                    String value = name.getText().toString().trim();
                    if (value.isEmpty()) return;
                    setStatus("Creando carpeta...", true, false);
                    executor.execute(() -> {
                        try {
                            JSONObject cfg = new JSONObject(a.configJson);
                            String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                            ImapConnector.createFolder(cfg, pass, value);
                            List<MailFolder> folders = ImapConnector.listFolders(cfg, pass);
                            folderStore.save(a.id, folders);
                            runOnUiThread(() -> {
                                setStatus("Carpeta creada en el servidor", false, false);
                                showFolders();
                            });
                        } catch (Exception e) {
                            setStatus("No pude crear la carpeta: " + shortError(e), false, true);
                        }
                    });
                }).show();
    }

    private void manageFolderDialog(MailAccount a, MailFolder folder) {
        new AlertDialog.Builder(this)
                .setTitle(folder.displayName)
                .setItems(new String[]{"Renombrar", "Eliminar del servidor"}, (d, which) -> {
                    if (which == 0) renameFolderDialog(a, folder);
                    else deleteFolderConfirm(a, folder);
                }).show();
    }

    private void renameFolderDialog(MailAccount a, MailFolder folder) {
        EditText name = Ui.input(this, "Nuevo nombre");
        name.setText(folder.name);
        new AlertDialog.Builder(this)
                .setTitle("Renombrar carpeta")
                .setView(name)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Renombrar", (d, w) -> {
                    String value = name.getText().toString().trim();
                    if (value.isEmpty() || value.equals(folder.name)) return;
                    setStatus("Renombrando carpeta...", true, false);
                    executor.execute(() -> {
                        try {
                            JSONObject cfg = new JSONObject(a.configJson);
                            String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                            ImapConnector.renameFolder(cfg, pass, folder.name, value);
                            folderStore.save(a.id, ImapConnector.listFolders(cfg, pass));
                            runOnUiThread(() -> {
                                setStatus("Carpeta renombrada", false, false);
                                showFolders();
                            });
                        } catch (Exception e) {
                            setStatus("No pude renombrar: " + shortError(e), false, true);
                        }
                    });
                }).show();
    }

    private void deleteFolderConfirm(MailAccount a, MailFolder folder) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar carpeta")
                .setMessage("Se eliminará “" + folder.displayName + "” del servidor. Esta acción puede afectar los correos que contiene.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Eliminar", (d, w) -> {
                    setStatus("Eliminando carpeta...", true, false);
                    executor.execute(() -> {
                        try {
                            JSONObject cfg = new JSONObject(a.configJson);
                            String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                            ImapConnector.deleteFolder(cfg, pass, folder.name);
                            db.deleteFolderCache(a.id, folder.name);
                            folderStore.save(a.id, ImapConnector.listFolders(cfg, pass));
                            runOnUiThread(() -> {
                                setStatus("Carpeta eliminada", false, false);
                                showFolders();
                            });
                        } catch (Exception e) {
                            setStatus("No pude eliminar la carpeta: " + shortError(e), false, true);
                        }
                    });
                }).show();
    }

    private void showRules() {
        prepare("Mis reglas", "Sólo existen las reglas que tú creas", null);
        Button add = Ui.button(this, "Crear regla", true);
        add.setOnClickListener(v -> showRuleDialog(null));
        content.addView(add, spaced());

        Button run = Ui.button(this, "Ejecutar reglas ahora", false);
        run.setOnClickListener(v -> runRulesNow());
        content.addView(run, spaced());

        List<MailRule> rules = ruleStore.all();
        if (rules.isEmpty()) {
            LinearLayout info = Ui.card(this);
            info.addView(Ui.text(this, "No hay reglas automáticas.", 15, Ui.TEXT, true));
            TextView d = Ui.text(this, "Ejemplo: en tu cuenta Gmail, si el remitente contiene “sat.gob.mx”, mover a la carpeta SAT.", 13, Ui.MUTED, false);
            d.setPadding(0, Ui.dp(this, 6), 0, 0);
            info.addView(d);
            content.addView(info, spacedTop(14));
            return;
        }

        for (MailRule r : rules) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.text(this, r.name, 15, Ui.TEXT, true));
            MailAccount a = accountStore.byId(r.accountId);
            String account = a == null ? "Cuenta no disponible" : a.email;
            card.addView(Ui.text(this, account + " · " + r.field + " contiene “" + r.contains + "”", 12, Ui.MUTED, false));
            card.addView(Ui.text(this, "→ " + displayFolder(r.accountId, r.category) + (r.enabled ? "" : " · desactivada"), 12, r.enabled ? Ui.CYAN : Ui.MUTED, true));

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setPadding(0, Ui.dp(this, 9), 0, 0);
            Button edit = Ui.compactButton(this, "Editar", false);
            Button del = Ui.compactButton(this, "Eliminar", false);
            actions.addView(edit, new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1));
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
            dp.setMargins(Ui.dp(this, 7), 0, 0, 0);
            actions.addView(del, dp);
            card.addView(actions);
            edit.setOnClickListener(v -> showRuleEditDialog(r));
            del.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Eliminar regla")
                    .setMessage(r.name)
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Eliminar", (d, w) -> { ruleStore.delete(r.id); showRules(); })
                    .show());
            content.addView(card, spaced());
        }
    }

    private void showRuleDialog(MailItem sample) {
        MailRule r = new MailRule();
        r.name = sample == null ? "" : "Regla para " + extractEmailOrSender(sample.from);
        r.accountId = sample == null ? firstImapAccountId() : sample.accountId;
        r.field = "Remitente";
        r.contains = sample == null ? "" : extractEmailOrSender(sample.from);
        r.category = "";
        r.enabled = true;
        showRuleEditDialog(r);
    }

    private void showRuleEditDialog(MailRule rule) {
        List<MailAccount> accounts = imapAccounts();
        if (accounts.isEmpty()) {
            toast("Necesitas una cuenta IMAP/SMTP para usar reglas con carpetas.");
            showAccounts();
            return;
        }

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 18), Ui.dp(this, 6), Ui.dp(this, 18), Ui.dp(this, 6));

        EditText name = Ui.input(this, "Nombre de la regla");
        name.setText(rule.name == null ? "" : rule.name);
        form.addView(name, spaced());

        Spinner account = new Spinner(this);
        List<String> accountLabels = new ArrayList<>();
        for (MailAccount a : accounts) accountLabels.add(a.email);
        account.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, accountLabels));
        int selectedAccount = 0;
        for (int i = 0; i < accounts.size(); i++) if (accounts.get(i).id.equals(rule.accountId)) selectedAccount = i;
        account.setSelection(selectedAccount);
        form.addView(account, spaced());

        Spinner field = new Spinner(this);
        String[] fields = {"Remitente", "Asunto", "Remitente o asunto"};
        field.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, fields));
        int fi = Arrays.asList(fields).indexOf(rule.field);
        field.setSelection(fi < 0 ? 0 : fi);
        form.addView(field, spaced());

        EditText contains = Ui.input(this, "Contiene...");
        contains.setText(rule.contains == null ? "" : rule.contains);
        form.addView(contains, spaced());

        Spinner destination = new Spinner(this);
        ArrayAdapter<String> destinationAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new ArrayList<>());
        destination.setAdapter(destinationAdapter);
        form.addView(destination, spaced());
        List<String> destinationNames = new ArrayList<>();

        Runnable updateFolders = () -> {
            MailAccount a = accounts.get(account.getSelectedItemPosition());
            List<MailFolder> folders = folderStore.all(a.id);
            destinationNames.clear();
            destinationAdapter.clear();
            int select = 0;
            for (int i = 0; i < folders.size(); i++) {
                MailFolder f = folders.get(i);
                destinationNames.add(f.name);
                destinationAdapter.add(f.displayName);
                if (f.name.equals(rule.category)) select = i;
            }
            destinationAdapter.notifyDataSetChanged();
            if (!destinationNames.isEmpty()) destination.setSelection(Math.min(select, destinationNames.size() - 1));
        };
        account.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { updateFolders.run(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        updateFolders.run();

        CheckBox enabled = new CheckBox(this);
        enabled.setText("Regla activa");
        enabled.setTextColor(Ui.TEXT);
        enabled.setChecked(rule.enabled);
        form.addView(enabled, spaced());

        ScrollView scroll = new ScrollView(this);
        scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(rule.id == null || rule.id.isEmpty() ? "Crear regla" : "Editar regla")
                .setView(scroll)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", null)
                .create();

        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (contains.getText().toString().trim().isEmpty()) { toast("Escribe qué debe contener"); return; }
            if (destinationNames.isEmpty()) { toast("Actualiza primero las carpetas de esa cuenta"); return; }
            MailAccount a = accounts.get(account.getSelectedItemPosition());
            rule.accountId = a.id;
            rule.name = name.getText().toString().trim();
            if (rule.name.isEmpty()) rule.name = "Mover a " + destination.getSelectedItem();
            rule.field = String.valueOf(field.getSelectedItem());
            rule.contains = contains.getText().toString().trim();
            rule.category = destinationNames.get(destination.getSelectedItemPosition());
            rule.enabled = enabled.isChecked();
            ruleStore.save(rule);
            dialog.dismiss();
            showRules();
        }));
        dialog.show();
    }

    private void runRulesNow() {
        List<MailAccount> accounts = imapAccounts();
        if (accounts.isEmpty()) return;
        setStatus("Ejecutando tus reglas...", true, false);
        executor.execute(() -> {
            try {
                int moved = 0;
                for (MailAccount a : accounts) moved += syncImapAccount(a, true);
                int finalMoved = moved;
                runOnUiThread(() -> {
                    setStatus("Reglas terminadas · " + finalMoved + " movimientos", false, false);
                    showRules();
                });
            } catch (Exception e) {
                setStatus("Error ejecutando reglas: " + shortError(e), false, true);
            }
        });
    }

    private void showAccounts() {
        prepare("Cuentas", "Entrada, salida y firma por cuenta", null);

        Button gmailApp = Ui.button(this, "Agregar Gmail con clave de aplicación", true);
        gmailApp.setOnClickListener(v -> showImapDialog(null, true));
        content.addView(gmailApp, spaced());

        Button other = Ui.button(this, "Agregar otra cuenta IMAP / SMTP", false);
        other.setOnClickListener(v -> showImapDialog(null, false));
        content.addView(other, spaced());

        List<MailAccount> list = accountStore.all();
        DateFormat fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
        for (MailAccount a : list) {
            LinearLayout card = Ui.card(this);
            card.addView(Ui.text(this, a.email == null || a.email.isEmpty() ? a.displayName : a.email, 16, Ui.TEXT, true));
            card.addView(Ui.text(this, providerName(a), 12, Ui.CYAN, false));
            if (MailAccount.IMAP.equals(a.provider)) {
                try {
                    JSONObject cfg = new JSONObject(a.configJson);
                    String in = cfg.optString("host") + ":" + cfg.optInt("port", 993);
                    String out = cfg.optString("smtpHost") + ":" + cfg.optInt("smtpPort", 465);
                    card.addView(Ui.text(this, "Entrada  " + in, 11, Ui.MUTED, false));
                    card.addView(Ui.text(this, "Salida   " + out, 11, Ui.MUTED, false));
                    if (!cfg.optString("signature").trim().isEmpty()) card.addView(Ui.text(this, "Firma configurada", 11, Ui.GREEN, false));
                } catch (Exception ignored) {}
            }
            String last = a.lastSync > 0 ? "Última actualización: " + fmt.format(new Date(a.lastSync)) : "Sin actualizar";
            card.addView(Ui.text(this, last, 11, Ui.MUTED, false));

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setPadding(0, Ui.dp(this, 10), 0, 0);
            Button edit = Ui.compactButton(this, "Editar", false);
            Button sync = Ui.compactButton(this, "Actualizar", true);
            Button del = Ui.compactButton(this, "Quitar", false);
            actions.addView(edit, new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1));
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
            sp.setMargins(Ui.dp(this, 6), 0, 0, 0);
            actions.addView(sync, sp);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1);
            dp.setMargins(Ui.dp(this, 6), 0, 0, 0);
            actions.addView(del, dp);
            card.addView(actions);

            edit.setEnabled(MailAccount.IMAP.equals(a.provider));
            edit.setOnClickListener(v -> showImapDialog(a, isGmailImap(a)));
            sync.setOnClickListener(v -> syncAccount(a));
            del.setOnClickListener(v -> confirmDelete(a));
            content.addView(card, spacedTop(12));
        }

        TextView advanced = Ui.text(this, "Conexiones avanzadas", 16, Ui.TEXT, true);
        content.addView(advanced, spacedTop(20));
        Button gmailOauth = Ui.button(this, "Gmail con OAuth", false);
        gmailOauth.setOnClickListener(v -> beginGmailAdd());
        content.addView(gmailOauth, spaced());
        Button ms = Ui.button(this, "Outlook / Hotmail con Microsoft", false);
        ms.setOnClickListener(v -> beginMicrosoftAdd());
        content.addView(ms, spaced());
    }

    private void showImapDialog(MailAccount existing, boolean gmailPreset) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.dp(this, 18), Ui.dp(this, 6), Ui.dp(this, 18), Ui.dp(this, 10));

        EditText email = Ui.input(this, "Correo completo");
        EditText imapHost = Ui.input(this, "Servidor de entrada IMAP");
        EditText imapPort = Ui.input(this, "Puerto de entrada");
        imapPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        CheckBox imapSsl = new CheckBox(this);
        imapSsl.setText("Entrada SSL/TLS (desactiva para STARTTLS)");
        imapSsl.setTextColor(Ui.TEXT);
        imapSsl.setChecked(true);
        EditText smtpHost = Ui.input(this, "Servidor de salida SMTP");
        EditText smtpPort = Ui.input(this, "Puerto de salida");
        smtpPort.setInputType(InputType.TYPE_CLASS_NUMBER);
        Spinner smtpSecurity = new Spinner(this);
        String[] security = {"SSL/TLS", "STARTTLS"};
        smtpSecurity.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, security));
        EditText user = Ui.input(this, "Usuario (vacío = correo)");
        EditText pass = Ui.input(this, existing == null ? "Contraseña / clave de aplicación" : "Nueva contraseña (vacío = conservar)");
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText signature = Ui.multiline(this, "Firma de esta cuenta", 3);

        JSONObject cfg = new JSONObject();
        try { if (existing != null) cfg = new JSONObject(existing.configJson); } catch (Exception ignored) {}
        if (existing != null) email.setText(existing.email);
        imapHost.setText(cfg.optString("host", gmailPreset ? "imap.gmail.com" : ""));
        imapPort.setText(String.valueOf(cfg.optInt("port", 993)));
        imapSsl.setChecked(cfg.optBoolean("ssl", true));
        smtpHost.setText(cfg.optString("smtpHost", gmailPreset ? "smtp.gmail.com" : ""));
        smtpPort.setText(String.valueOf(cfg.optInt("smtpPort", 465)));
        smtpSecurity.setSelection("STARTTLS".equalsIgnoreCase(cfg.optString("smtpSecurity")) ? 1 : 0);
        user.setText(cfg.optString("username", ""));
        signature.setText(cfg.optString("signature", ""));

        if (gmailPreset && existing == null) {
            imapHost.setText("imap.gmail.com"); imapPort.setText("993");
            smtpHost.setText("smtp.gmail.com"); smtpPort.setText("465");
            smtpSecurity.setSelection(0);
        }

        form.addView(section("Entrada IMAP"), spaced());
        form.addView(email, spaced());
        form.addView(imapHost, spaced());
        form.addView(imapPort, spaced());
        form.addView(imapSsl, spaced());
        form.addView(section("Salida SMTP"), spacedTop(12));
        form.addView(smtpHost, spaced());
        form.addView(smtpPort, spaced());
        form.addView(smtpSecurity, spaced());
        form.addView(section("Acceso"), spacedTop(12));
        form.addView(user, spaced());
        form.addView(pass, spaced());
        form.addView(section("Firma"), spacedTop(12));
        form.addView(signature, spaced());

        ScrollView scroll = new ScrollView(this);
        scroll.addView(form);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(existing == null ? (gmailPreset ? "Agregar Gmail" : "Agregar IMAP / SMTP") : "Editar cuenta")
                .setView(scroll)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", null)
                .create();

        JSONObject finalCfg = cfg;
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String mail = email.getText().toString().trim();
            String inHost = imapHost.getText().toString().trim();
            String outHost = smtpHost.getText().toString().trim();
            String password = pass.getText().toString();
            if (mail.isEmpty() || inHost.isEmpty() || outHost.isEmpty()) { toast("Completa correo, entrada y salida"); return; }
            if (existing == null && password.isEmpty()) { toast("Escribe la contraseña o clave de aplicación"); return; }
            try {
                MailAccount a = existing == null ? new MailAccount() : existing;
                if (a.id == null || a.id.isEmpty()) a.id = UUID.randomUUID().toString();
                a.provider = MailAccount.IMAP;
                a.email = mail;
                a.displayName = mail;
                JSONObject c = finalCfg;
                c.put("host", inHost);
                c.put("port", parseInt(imapPort.getText().toString(), imapSsl.isChecked() ? 993 : 143));
                c.put("ssl", imapSsl.isChecked());
                c.put("imapSecurity", imapSsl.isChecked() ? "SSL" : "STARTTLS");
                c.put("username", user.getText().toString().trim().isEmpty() ? mail : user.getText().toString().trim());
                c.put("smtpHost", outHost);
                c.put("smtpPort", parseInt(smtpPort.getText().toString(), smtpSecurity.getSelectedItemPosition() == 1 ? 587 : 465));
                c.put("smtpSecurity", smtpSecurity.getSelectedItemPosition() == 1 ? "STARTTLS" : "SSL");
                c.put("smtpUsername", user.getText().toString().trim().isEmpty() ? mail : user.getText().toString().trim());
                c.put("signature", signature.getText().toString());
                c.put("preset", gmailPreset ? "gmail" : c.optString("preset", "generic"));
                a.configJson = c.toString();
                accountStore.save(a);
                if (!password.isEmpty()) accountStore.secure().put("imap_pass_" + a.id, password);
                dialog.dismiss();
                syncAccount(a);
            } catch (Exception e) {
                toast("No pude guardar la cuenta: " + shortError(e));
            }
        }));
        dialog.show();
    }

    private TextView section(String value) { return Ui.text(this, value, 13, Ui.CYAN, true); }

    private void confirmDelete(MailAccount a) {
        new AlertDialog.Builder(this)
                .setTitle("Quitar cuenta")
                .setMessage("Se quitará sólo de Correo Fácil. No se borrará nada del servidor.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Quitar", (d, w) -> {
                    accountStore.delete(a.id);
                    folderStore.clear(a.id);
                    db.deleteAccount(a.id);
                    showAccounts();
                }).show();
    }

    private void showCompose(MailItem replyTo) {
        List<MailAccount> accounts = imapAccounts();
        if (accounts.isEmpty()) {
            toast("Para enviar, agrega una cuenta con salida SMTP.");
            showAccounts();
            return;
        }
        prepare(replyTo == null ? "Nuevo correo" : "Responder", "Envío directo por SMTP", this::showDashboard);

        Spinner account = new Spinner(this);
        List<String> labels = new ArrayList<>();
        for (MailAccount a : accounts) labels.add(a.email);
        account.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, labels));
        if (replyTo != null) for (int i = 0; i < accounts.size(); i++) if (accounts.get(i).id.equals(replyTo.accountId)) account.setSelection(i);
        content.addView(account, spaced());

        EditText to = Ui.input(this, "Para");
        EditText cc = Ui.input(this, "CC (opcional)");
        EditText bcc = Ui.input(this, "CCO (opcional)");
        EditText subject = Ui.input(this, "Asunto");
        EditText body = Ui.multiline(this, "Mensaje", 8);
        if (replyTo != null) {
            to.setText(extractEmailOrSender(replyTo.from));
            String s = replyTo.subject == null ? "" : replyTo.subject;
            subject.setText(s.toLowerCase().startsWith("re:") ? s : "Re: " + s);
        }
        content.addView(to, spaced());
        content.addView(cc, spaced());
        content.addView(bcc, spaced());
        content.addView(subject, spaced());
        content.addView(body, spaced());

        TextView signaturePreview = Ui.text(this, "", 12, Ui.MUTED, false);
        content.addView(signaturePreview, spaced());
        Runnable updateSignature = () -> {
            MailAccount a = accounts.get(account.getSelectedItemPosition());
            try {
                String sig = new JSONObject(a.configJson).optString("signature");
                signaturePreview.setText(sig.trim().isEmpty() ? "Sin firma" : "Firma:\n" + sig);
            } catch (Exception e) { signaturePreview.setText("Sin firma"); }
        };
        account.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { updateSignature.run(); }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        updateSignature.run();

        Button send = Ui.button(this, "Enviar", true);
        content.addView(send, spacedTop(12));
        send.setOnClickListener(v -> {
            if (to.getText().toString().trim().isEmpty()) { toast("Falta el destinatario"); return; }
            MailAccount a = accounts.get(account.getSelectedItemPosition());
            setStatus("Enviando desde " + a.email + "...", true, false);
            send.setEnabled(false);
            executor.execute(() -> {
                try {
                    JSONObject cfg = new JSONObject(a.configJson);
                    String pass = accountStore.secure().get("imap_pass_" + a.id, "");
                    ImapConnector.send(cfg, pass, a.email,
                            to.getText().toString().trim(), cc.getText().toString().trim(), bcc.getText().toString().trim(),
                            subject.getText().toString(), body.getText().toString(), cfg.optString("signature"));
                    runOnUiThread(() -> {
                        setStatus("Correo enviado", false, false);
                        Toast.makeText(this, "Correo enviado", Toast.LENGTH_SHORT).show();
                        showDashboard();
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> send.setEnabled(true));
                    setStatus("No pude enviar: " + shortError(e), false, true);
                }
            });
        });
    }

    private void showSettings() {
        prepare("Ajustes", "Ligero, manual y sin procesos ocultos", null);

        LinearLayout behavior = Ui.card(this);
        behavior.addView(Ui.text(this, "Comportamiento", 16, Ui.TEXT, true));
        behavior.addView(Ui.text(this, "• Atrás dos veces para salir.\n• El cuerpo del correo se descarga sólo al abrirlo.\n• Sin sincronización automática en segundo plano.\n• Sin clasificación automática: sólo tus reglas.", 13, Ui.MUTED, false));
        content.addView(behavior, spaced());

        LinearLayout microsoft = Ui.card(this);
        microsoft.addView(Ui.text(this, "Microsoft OAuth", 16, Ui.TEXT, true));
        EditText clientId = Ui.input(this, "Microsoft Client ID");
        clientId.setText(accountStore.secure().get("microsoft_client_id", ""));
        microsoft.addView(clientId, spaced());
        Button save = Ui.button(this, "Guardar Client ID", false);
        save.setOnClickListener(v -> {
            accountStore.secure().put("microsoft_client_id", clientId.getText().toString().trim());
            setStatus("Ajustes guardados", false, false);
        });
        microsoft.addView(save);
        content.addView(microsoft, spaced());

        LinearLayout privacy = Ui.card(this);
        privacy.addView(Ui.text(this, "Privacidad", 16, Ui.TEXT, true));
        privacy.addView(Ui.text(this, "Contraseñas y tokens se guardan cifrados con Android Keystore. Correo Fácil no tiene anuncios, analítica ni servidor propio.", 13, Ui.MUTED, false));
        content.addView(privacy, spaced());

        LinearLayout about = Ui.card(this);
        about.addView(Ui.text(this, "Correo Fácil 1.2.0", 15, Ui.TEXT, true));
        about.addView(Ui.text(this, "Cliente ligero IMAP/SMTP con carpetas bidireccionales, reglas propias, selección masiva y firmas por cuenta.", 12, Ui.MUTED, false));
        content.addView(about, spaced());

        Button appInfo = Ui.button(this, "Información de la app", false);
        appInfo.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        content.addView(appInfo, spaced());
    }

    private void syncAll() {
        List<MailAccount> all = accountStore.all();
        if (all.isEmpty()) { showAccounts(); return; }
        List<MailAccount> imap = imapAccounts();
        setStatus("Actualizando " + imap.size() + " cuentas IMAP/SMTP...", true, false);
        executor.execute(() -> {
            try {
                int moved = 0;
                for (int i = 0; i < imap.size(); i++) {
                    MailAccount a = imap.get(i);
                    final int pos = i + 1;
                    runOnUiThread(() -> setStatus("Sincronizando " + pos + "/" + imap.size() + " · " + a.email, true, false));
                    moved += syncImapAccount(a, true);
                }
                int finalMoved = moved;
                runOnUiThread(() -> {
                    setStatus("Actualización terminada" + (finalMoved > 0 ? " · reglas movieron " + finalMoved : ""), false, false);
                    showDashboard();
                });
            } catch (Exception e) {
                setStatus("Error de sincronización: " + shortError(e), false, true);
            }
        });

        // OAuth se mantiene disponible, pero no se dispara automáticamente para no abrir diálogos inesperados.
    }

    private void syncAccount(MailAccount a) {
        if (MailAccount.IMAP.equals(a.provider)) {
            setStatus("Conectando con " + a.email + "...", true, false);
            executor.execute(() -> {
                try {
                    int moved = syncImapAccount(a, true);
                    runOnUiThread(() -> {
                        setStatus("Actualizado: " + a.email + (moved > 0 ? " · " + moved + " movidos por reglas" : ""), false, false);
                        showAccounts();
                    });
                } catch (Exception e) {
                    setStatus("No pude conectar: " + shortError(e), false, true);
                }
            });
            return;
        }
        if (MailAccount.GMAIL.equals(a.provider)) {
            authorizeGmail(a.id);
            return;
        }
        if (MailAccount.MICROSOFT.equals(a.provider)) syncMicrosoftAccount(a);
    }

    private int syncImapAccount(MailAccount a, boolean applyRules) throws Exception {
        JSONObject cfg = new JSONObject(a.configJson);
        String pass = accountStore.secure().get("imap_pass_" + a.id, "");
        if (pass.isEmpty()) throw new IllegalStateException("Falta la contraseña de la cuenta");

        List<MailFolder> folders = ImapConnector.listFolders(cfg, pass);
        folderStore.save(a.id, folders);
        List<MailItem> mails = ImapConnector.syncFolder(a.id, cfg, pass, "INBOX", 100);
        int moved = 0;

        if (applyRules) {
            Map<String, List<MailItem>> destinations = new LinkedHashMap<>();
            for (MailItem m : mails) {
                String destination = ruleStore.match(m);
                if (destination != null && !destination.isEmpty() && !destination.equals(m.folder)) {
                    destinations.computeIfAbsent(destination, k -> new ArrayList<>()).add(m);
                }
            }
            for (Map.Entry<String, List<MailItem>> e : destinations.entrySet()) {
                ImapConnector.moveMessages(cfg, pass, "INBOX", ids(e.getValue()), e.getKey());
                for (MailItem m : e.getValue()) m.folder = e.getKey();
                moved += e.getValue().size();
            }
        }

        db.deleteFolderCache(a.id, "INBOX");
        db.upsert(mails);
        a.lastSync = System.currentTimeMillis();
        accountStore.save(a);
        return moved;
    }

    private void beginGmailAdd() {
        MailAccount a = new MailAccount();
        a.id = UUID.randomUUID().toString();
        a.provider = MailAccount.GMAIL;
        a.displayName = "Gmail OAuth";
        pendingGmailAccountId = a.id;
        accountStore.save(a);
        authorizeGmail(a.id);
    }

    private void authorizeGmail(String accountId) {
        pendingGmailAccountId = accountId;
        setStatus("Solicitando autorización de Google...", true, false);
        AuthorizationRequest request = new AuthorizationRequest.Builder()
                .setRequestedScopes(Arrays.asList(
                        new Scope("https://www.googleapis.com/auth/gmail.modify"),
                        new Scope("openid"), new Scope("email")))
                .build();
        Identity.getAuthorizationClient(this).authorize(request)
                .addOnSuccessListener(result -> {
                    if (result.hasResolution() && result.getPendingIntent() != null) {
                        try {
                            gmailResolutionLauncher.launch(new IntentSenderRequest.Builder(result.getPendingIntent().getIntentSender()).build());
                        } catch (Exception e) {
                            setStatus("No pude abrir Google", false, true);
                        }
                    } else handleGmailToken(result.getAccessToken());
                })
                .addOnFailureListener(e -> {
                    setStatus("Gmail OAuth requiere configurar Google Cloud", false, true);
                    showGmailSetupHelp();
                });
    }

    private void handleGmailToken(String accessToken) {
        if (accessToken == null || accessToken.isEmpty()) { setStatus("Google no devolvió acceso", false, true); return; }
        String accountId = pendingGmailAccountId;
        executor.execute(() -> {
            try {
                String email = GmailConnector.fetchEmail(accessToken);
                MailAccount a = accountStore.byId(accountId);
                if (a == null) return;
                a.email = email; a.displayName = email;
                List<MailItem> mails = GmailConnector.sync(a.id, accessToken);
                db.deleteFolderCache(a.id, "INBOX");
                db.upsert(mails);
                a.lastSync = System.currentTimeMillis();
                accountStore.save(a);
                runOnUiThread(() -> { setStatus("Gmail conectado", false, false); showAccounts(); });
            } catch (Exception e) { setStatus("No pude leer Gmail: " + shortError(e), false, true); }
        });
    }

    private void showGmailSetupHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Gmail OAuth")
                .setMessage("La opción más sencilla es Gmail con clave de aplicación. OAuth requiere registrar com.correoclaro.app y la firma SHA-1 en Google Cloud.")
                .setPositiveButton("Entendido", null).show();
    }

    private void beginMicrosoftAdd() {
        String clientId = accountStore.secure().get("microsoft_client_id", "");
        if (clientId.isEmpty()) { toast("Primero guarda el Client ID de Microsoft en Ajustes."); showSettings(); return; }
        MailAccount a = new MailAccount();
        a.id = UUID.randomUUID().toString(); a.provider = MailAccount.MICROSOFT; a.displayName = "Microsoft";
        accountStore.save(a);
        authorizeMicrosoft(a.id);
    }

    private void authorizeMicrosoft(String accountId) {
        String clientId = accountStore.secure().get("microsoft_client_id", "");
        if (clientId.isEmpty()) return;
        pendingMicrosoftAccountId = accountId;
        AuthorizationServiceConfiguration config = new AuthorizationServiceConfiguration(
                Uri.parse("https://login.microsoftonline.com/common/oauth2/v2.0/authorize"),
                Uri.parse("https://login.microsoftonline.com/common/oauth2/v2.0/token"));
        net.openid.appauth.AuthorizationRequest request = new Builder(config, clientId, ResponseTypeValues.CODE,
                Uri.parse("com.correoclaro.app:/oauth2redirect"))
                .setScopes("openid", "profile", "offline_access", "User.Read", "Mail.ReadWrite")
                .build();
        microsoftAuthLauncher.launch(authService.getAuthorizationRequestIntent(request));
    }

    private void handleMicrosoftAuthResult(int resultCode, Intent data) {
        if (data == null || pendingMicrosoftAccountId == null) return;
        AuthorizationResponse response = AuthorizationResponse.fromIntent(data);
        AuthorizationException ex = AuthorizationException.fromIntent(data);
        if (response == null) { setStatus("Microsoft no autorizó la cuenta", false, true); return; }
        AuthState state = new AuthState(response, ex);
        String accountId = pendingMicrosoftAccountId;
        authService.performTokenRequest(response.createTokenExchangeRequest(), (tokenResponse, tokenEx) -> {
            state.update(tokenResponse, tokenEx);
            if (tokenResponse == null || tokenResponse.accessToken == null) {
                runOnUiThread(() -> setStatus("No pude obtener acceso de Microsoft", false, true));
                return;
            }
            accountStore.secure().put("ms_auth_" + accountId, state.jsonSerializeString());
            finishMicrosoftConnection(accountId, tokenResponse.accessToken);
        });
    }

    private void finishMicrosoftConnection(String accountId, String token) {
        executor.execute(() -> {
            try {
                JSONObject p = MicrosoftConnector.profile(token);
                String email = p.optString("mail"); if (email.isEmpty()) email = p.optString("userPrincipalName");
                MailAccount a = accountStore.byId(accountId); if (a == null) return;
                a.email = email; a.displayName = p.optString("displayName", email);
                List<MailItem> mails = MicrosoftConnector.sync(a.id, token);
                db.deleteFolderCache(a.id, "INBOX"); db.upsert(mails);
                a.lastSync = System.currentTimeMillis(); accountStore.save(a);
                runOnUiThread(() -> { setStatus("Microsoft conectado", false, false); showAccounts(); });
            } catch (Exception e) { setStatus("No pude leer Microsoft: " + shortError(e), false, true); }
        });
    }

    private void syncMicrosoftAccount(MailAccount a) {
        String raw = accountStore.secure().get("ms_auth_" + a.id, "");
        if (raw.isEmpty()) { pendingMicrosoftAccountId = a.id; authorizeMicrosoft(a.id); return; }
        try {
            AuthState state = AuthState.jsonDeserialize(raw);
            state.performActionWithFreshTokens(authService, (accessToken, idToken, ex) -> {
                if (ex != null || accessToken == null) {
                    runOnUiThread(() -> authorizeMicrosoft(a.id));
                    return;
                }
                accountStore.secure().put("ms_auth_" + a.id, state.jsonSerializeString());
                executor.execute(() -> {
                    try {
                        List<MailItem> mails = MicrosoftConnector.sync(a.id, accessToken);
                        db.deleteFolderCache(a.id, "INBOX"); db.upsert(mails);
                        a.lastSync = System.currentTimeMillis(); accountStore.save(a);
                        runOnUiThread(() -> { setStatus("Microsoft actualizado", false, false); showAccounts(); });
                    } catch (Exception e) { setStatus("Error Microsoft: " + shortError(e), false, true); }
                });
            });
        } catch (Exception e) { authorizeMicrosoft(a.id); }
    }

    private String providerName(MailAccount a) {
        if (MailAccount.GMAIL.equals(a.provider)) return "Gmail · OAuth";
        if (MailAccount.MICROSOFT.equals(a.provider)) return "Microsoft · OAuth";
        return isGmailImap(a) ? "Gmail · IMAP/SMTP" : "IMAP/SMTP";
    }

    private boolean isGmailImap(MailAccount a) {
        if (a == null || !MailAccount.IMAP.equals(a.provider)) return false;
        try {
            JSONObject cfg = new JSONObject(a.configJson);
            return "gmail".equalsIgnoreCase(cfg.optString("preset")) || "imap.gmail.com".equalsIgnoreCase(cfg.optString("host"));
        } catch (Exception e) { return false; }
    }

    private List<MailAccount> imapAccounts() {
        List<MailAccount> out = new ArrayList<>();
        for (MailAccount a : accountStore.all()) if (MailAccount.IMAP.equals(a.provider)) out.add(a);
        return out;
    }

    private String firstImapAccountId() {
        List<MailAccount> list = imapAccounts();
        return list.isEmpty() ? "" : list.get(0).id;
    }

    private String displayFolder(String accountId, String folderName) {
        if (folderName == null || folderName.isEmpty()) return "Entrada";
        MailFolder f = folderStore.byName(accountId, folderName);
        if (f != null && f.displayName != null && !f.displayName.isEmpty()) return f.displayName;
        if ("INBOX".equalsIgnoreCase(folderName)) return "Entrada";
        return folderName;
    }

    private String extractEmailOrSender(String from) {
        if (from == null) return "";
        int a = from.indexOf('<'); int b = from.indexOf('>');
        if (a >= 0 && b > a) return from.substring(a + 1, b).trim();
        return from.trim();
    }

    private int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return fallback; }
    }

    private String shortError(Exception e) {
        String s = e.getMessage();
        if (s == null || s.trim().isEmpty()) return e.getClass().getSimpleName();
        s = s.replace('\n', ' ').replace('\r', ' ');
        return s.length() > 150 ? s.substring(0, 150) : s;
    }

    private LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams p = Ui.mp(LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
        return p;
    }

    private LinearLayout.LayoutParams spacedTop(int top) {
        LinearLayout.LayoutParams p = Ui.mp(LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, Ui.dp(this, top), 0, Ui.dp(this, 6));
        return p;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
