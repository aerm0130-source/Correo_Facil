package com.correoclaro.app.model;

import org.json.JSONException;
import org.json.JSONObject;

public class MailFolder {
    public String name;
    public String displayName;
    public String special;

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("name", name == null ? "" : name);
        o.put("displayName", displayName == null ? "" : displayName);
        o.put("special", special == null ? "" : special);
        return o;
    }

    public static MailFolder fromJson(JSONObject o) {
        MailFolder f = new MailFolder();
        f.name = o.optString("name");
        f.displayName = o.optString("displayName", f.name);
        f.special = o.optString("special");
        return f;
    }

    public boolean isProtected() {
        if (special == null) return false;
        return !special.isEmpty();
    }
}
