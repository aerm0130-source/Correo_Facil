# Correo Claro

Aplicación Android de solo lectura para centralizar y clasificar correo de:
- Gmail (Google OAuth / Gmail API)
- Outlook / Hotmail / Microsoft 365 (OAuth / Microsoft Graph)
- Dominios propios (IMAP)

## Filosofía de la v1
- No borra correos.
- No envía correos.
- No mueve mensajes.
- Clasificación local en el teléfono.
- Sin servidor propio obligatorio.
- IMAP puede funcionar de inmediato con los datos del servidor.
- Gmail y Microsoft requieren registrar una aplicación OAuth una sola vez.

## Compilación
El proyecto usa Android Gradle Plugin 8.7.3, Java 17, Gradle 8.9 y compileSdk 35.

## Gmail
La app usa Google Play Services AuthorizationClient y solicita:
`https://www.googleapis.com/auth/gmail.readonly`

Para autorizar una APK propia, crea un proyecto en Google Cloud, habilita Gmail API y registra un cliente OAuth Android con:
- Package: `com.correoclaro.app`
- SHA-1: el de la firma usada para compilar/instalar.

La compilación debug de GitHub Actions cambia de firma si cambia el keystore. Para uso estable conviene generar y conservar un keystore de release.

## Microsoft
Registra una aplicación pública en Microsoft Entra.
Configura como redirect URI:
`com.correoclaro.app:/oauth2redirect`

Permisos delegados:
- `openid`
- `profile`
- `offline_access`
- `User.Read`
- `Mail.Read`

Después pega el Client ID en Configuración dentro de la app.

## IMAP
Se puede agregar una cuenta de dominio propio indicando:
- servidor IMAP
- puerto
- SSL
- usuario
- contraseña o contraseña de aplicación

Las credenciales se guardan cifradas con Android Keystore.
