# Correo Facil Android

Version 1.2.0. Cliente de correo ligero para Android.

## Incluye
- Gmail por IMAP/SMTP con clave de aplicacion.
- IMAP/SMTP generico con puertos de entrada y salida configurables.
- Carpetas del servidor sincronizadas con la app.
- Crear, renombrar y eliminar carpetas en el servidor.
- Reglas creadas exclusivamente por el usuario para mover correo a carpetas.
- Seleccion multiple y acciones masivas: leido, no leido, pendiente, mover y papelera.
- Envio SMTP desde la app.
- Firma independiente por cuenta.
- Estado visible de sincronizacion y operaciones.
- Doble pulsacion de Atras para salir desde pantallas principales.
- El cuerpo de los mensajes IMAP se descarga solo al abrirlo para reducir datos, memoria y almacenamiento.
- Sin anuncios, analitica ni backend propio.

## Actualizaciones
El applicationId permanece como `com.correoclaro.app`. El workflow conserva `~/.android/debug.keystore` mediante cache con la clave `correo-facil-debug-signing-v1`, para que las compilaciones posteriores mantengan la firma una vez creada.


## Version 1.2.1
- Corrige bloqueos ANR en listas grandes.
- Muestra 25 correos por bloque y permite cargar mas.
- Filtra no leidos directamente en SQLite.
- Usa hasta 3 tareas de IO para que abrir un correo no espere a toda la sincronizacion.
- Ignora respuestas de red de pantallas que ya se cerraron.
- Limita el cuerpo visible a 40 mil caracteres para mantener la interfaz fluida.
