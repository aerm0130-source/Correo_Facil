# Correo Facil Android

Version 1.2.0. Cliente de correo ligero para Android.

## Incluye
- Gmail por IMAP/SMTP con clave de aplicacion.
- IMAP/SMTP generico con puertos de entrada y salida configurables.
- Carpetas del servidor sincronizadas con la app.
- Crear, renombrar y eliminar carpetas en el servidor.
- Reglas creadas exclusivamente por el usuario para mover correo a carpetas.
- Seleccion multiple y acciones masivas: leido, no leido, pendiente, mover y papelera.
- Envio SMTP desde la app.
- Firma independiente por cuenta.
- Estado visible de sincronizacion y operaciones.
- Doble pulsacion de Atras para salir desde pantallas principales.
- El cuerpo de los mensajes IMAP se descarga solo al abrirlo para reducir datos, memoria y almacenamiento.
- Sin anuncios, analitica ni backend propio.

## Actualizaciones
El applicationId permanece como `com.correoclaro.app`. El workflow conserva `~/.android/debug.keystore` mediante cache con la clave `correo-facil-debug-signing-v1`, para que las compilaciones posteriores mantengan la firma una vez creada.


## Version 1.2.1
- Corrige bloqueos ANR en listas grandes.
- Muestra 25 correos por bloque y permite cargar mas.
- Filtra no leidos directamente en SQLite.
- Usa hasta 3 tareas de IO para que abrir un correo no espere a toda la sincronizacion.
- Ignora respuestas de red de pantallas que ya se cerraron.
- Limita el cuerpo visible a 40 mil caracteres para mantener la interfaz fluida.


## Version 1.3.0 - sincronizacion rapida
- Sincronizacion incremental por UID: despues de la primera carga solo pide correos nuevos.
- Prefetch de encabezados, flags y UID en bloque.
- No relee la lista de carpetas en cada sincronizacion; usa cache y se actualiza manualmente.
- Las reglas se cargan una sola vez por ejecucion.
- Varios destinos de reglas se mueven con una sola conexion IMAP.
- Ejecutar reglas ahora usa el cache local y no vuelve a descargar la bandeja.
- Nuevos operadores: Contiene, No contiene, Es igual a, Empieza con, Termina con, Dominio es y Uno de.
- Campo adicional: Dominio del remitente.
- El estado muestra tiempo y cantidad de mensajes nuevos/movidos.
